"""
Seed script — populates NEXO with a realistic AutoSys-style batch workflow.
Creates a payroll processing pipeline with dependencies, schedules, and calendars.
"""

import asyncio
from datetime import date, timedelta
from app.database import async_session_factory, init_db
from app.models.jobs import JobDefinition
from app.models.dependencies import DependencyEdge
from app.models.calendars import Calendar
from app.models.enums import JobType, ConditionOperator


SEED_JOBS = [
    # ── Box Job: Payroll Processing ──────────────────────────────
    {
        "job_name": "BOX_PAYROLL",
        "job_type": JobType.BOX,
        "description": "Master payroll processing box",
        "start_times": "02:00",
        "start_days": "mo,tu,we,th,fr",
        "owner": "payroll_team",
        "tags": ["payroll", "critical"],
        "priority": 10,
    },
    # Children of BOX_PAYROLL
    {
        "job_name": "CMD_EXTRACT_HR_DATA",
        "job_type": JobType.CMD,
        "command": "echo 'Extracting HR data...' && sleep 2 && echo 'Done'",
        "machine": "localhost",
        "box_name": "BOX_PAYROLL",
        "description": "Extract employee data from HR system",
        "max_retries": 2,
        "retry_interval": 60,
        "alarm_if_fail": True,
        "tags": ["payroll", "extract"],
    },
    {
        "job_name": "CMD_EXTRACT_TIMESHEET",
        "job_type": JobType.CMD,
        "command": "echo 'Extracting timesheet data...' && sleep 3 && echo 'Done'",
        "machine": "localhost",
        "box_name": "BOX_PAYROLL",
        "description": "Extract timesheet entries",
        "max_retries": 2,
        "tags": ["payroll", "extract"],
    },
    {
        "job_name": "CMD_CALC_PAYROLL",
        "job_type": JobType.CMD,
        "command": "echo 'Calculating payroll...' && sleep 5 && echo 'Payroll calculated'",
        "machine": "localhost",
        "box_name": "BOX_PAYROLL",
        "condition": "s(CMD_EXTRACT_HR_DATA) & s(CMD_EXTRACT_TIMESHEET)",
        "description": "Calculate gross/net pay for all employees",
        "max_run_alarm": 30,
        "tags": ["payroll", "compute"],
        "priority": 5,
    },
    {
        "job_name": "CMD_GENERATE_PAYSLIPS",
        "job_type": JobType.CMD,
        "command": "echo 'Generating payslips...' && sleep 2 && echo 'Payslips generated'",
        "machine": "localhost",
        "box_name": "BOX_PAYROLL",
        "condition": "s(CMD_CALC_PAYROLL)",
        "description": "Generate PDF payslips",
        "tags": ["payroll", "output"],
    },
    {
        "job_name": "CMD_SEND_BANK_FILE",
        "job_type": JobType.CMD,
        "command": "echo 'Sending bank file...' && sleep 1 && echo 'Bank file sent'",
        "machine": "localhost",
        "box_name": "BOX_PAYROLL",
        "condition": "s(CMD_CALC_PAYROLL)",
        "description": "Transmit payment file to bank",
        "alarm_if_fail": True,
        "max_retries": 3,
        "tags": ["payroll", "banking", "critical"],
        "priority": 10,
    },

    # ── Box Job: GL Close ────────────────────────────────────────
    {
        "job_name": "BOX_GL_CLOSE",
        "job_type": JobType.BOX,
        "description": "General Ledger daily close process",
        "start_times": "23:00",
        "start_days": "mo,tu,we,th,fr",
        "owner": "finance_team",
        "tags": ["finance", "gl", "critical"],
    },
    {
        "job_name": "CMD_GL_EXTRACT",
        "job_type": JobType.CMD,
        "command": "echo 'GL extract running...' && sleep 4 && echo 'Done'",
        "machine": "localhost",
        "box_name": "BOX_GL_CLOSE",
        "description": "Extract GL transactions",
        "tags": ["finance", "extract"],
    },
    {
        "job_name": "CMD_GL_VALIDATE",
        "job_type": JobType.CMD,
        "command": "echo 'Validating GL entries...' && sleep 3 && echo 'Valid'",
        "machine": "localhost",
        "box_name": "BOX_GL_CLOSE",
        "condition": "s(CMD_GL_EXTRACT)",
        "description": "Validate GL entries and balances",
        "tags": ["finance", "validation"],
    },
    {
        "job_name": "CMD_GL_POST",
        "job_type": JobType.CMD,
        "command": "echo 'Posting GL entries...' && sleep 2 && echo 'Posted'",
        "machine": "localhost",
        "box_name": "BOX_GL_CLOSE",
        "condition": "s(CMD_GL_VALIDATE)",
        "description": "Post validated GL entries",
        "max_retries": 1,
        "tags": ["finance", "post"],
        "priority": 8,
    },

    # ── Standalone: Report Generation (depends on both boxes) ────
    {
        "job_name": "CMD_DAILY_REPORT",
        "job_type": JobType.CMD,
        "command": "echo 'Generating daily report...' && sleep 3 && echo 'Report ready'",
        "machine": "localhost",
        "condition": "s(BOX_PAYROLL) & s(BOX_GL_CLOSE)",
        "start_times": "06:00",
        "description": "Daily consolidated financial report",
        "owner": "reporting_team",
        "tags": ["reporting"],
    },

    # ── File Watcher ─────────────────────────────────────────────
    {
        "job_name": "FW_VENDOR_INVOICE",
        "job_type": JobType.FW,
        "watch_file": "/tmp/nexo/vendor_invoices/incoming.csv",
        "watch_interval": 30,
        "max_run_alarm": 120,
        "description": "Watch for incoming vendor invoice file",
        "tags": ["vendor", "file_watch"],
    },
    {
        "job_name": "CMD_PROCESS_INVOICES",
        "job_type": JobType.CMD,
        "command": "echo 'Processing vendor invoices...' && sleep 4 && echo 'Processed'",
        "machine": "localhost",
        "condition": "s(FW_VENDOR_INVOICE)",
        "description": "Process incoming vendor invoices",
        "tags": ["vendor", "processing"],
    },

    # ── Standalone scheduled jobs ────────────────────────────────
    {
        "job_name": "CMD_CLEANUP_LOGS",
        "job_type": JobType.CMD,
        "command": "echo 'Cleaning up old logs...' && sleep 1 && echo 'Cleaned'",
        "machine": "localhost",
        "cron_expression": "0 4 * * *",
        "description": "Daily log cleanup job",
        "tags": ["maintenance"],
    },
    {
        "job_name": "CMD_HEALTH_CHECK",
        "job_type": JobType.CMD,
        "command": "echo 'System health check...' && sleep 1 && echo 'All systems nominal'",
        "machine": "localhost",
        "cron_expression": "*/15 * * * *",
        "description": "Periodic system health check",
        "tags": ["monitoring", "health"],
    },
]

SEED_DEPENDENCIES = [
    ("CMD_EXTRACT_HR_DATA", "CMD_CALC_PAYROLL", ConditionOperator.SUCCESS),
    ("CMD_EXTRACT_TIMESHEET", "CMD_CALC_PAYROLL", ConditionOperator.SUCCESS),
    ("CMD_CALC_PAYROLL", "CMD_GENERATE_PAYSLIPS", ConditionOperator.SUCCESS),
    ("CMD_CALC_PAYROLL", "CMD_SEND_BANK_FILE", ConditionOperator.SUCCESS),
    ("CMD_GL_EXTRACT", "CMD_GL_VALIDATE", ConditionOperator.SUCCESS),
    ("CMD_GL_VALIDATE", "CMD_GL_POST", ConditionOperator.SUCCESS),
    ("BOX_PAYROLL", "CMD_DAILY_REPORT", ConditionOperator.SUCCESS),
    ("BOX_GL_CLOSE", "CMD_DAILY_REPORT", ConditionOperator.SUCCESS),
    ("FW_VENDOR_INVOICE", "CMD_PROCESS_INVOICES", ConditionOperator.SUCCESS),
]


async def seed():
    await init_db()

    async with async_session_factory() as db:
        # Check if already seeded
        from sqlalchemy import select, func
        result = await db.execute(select(func.count(JobDefinition.id)))
        if result.scalar() > 0:
            print("Database already seeded. Skipping.")
            return

        # Create jobs
        for job_data in SEED_JOBS:
            job = JobDefinition(**job_data)
            db.add(job)
        await db.flush()
        print(f"Created {len(SEED_JOBS)} job definitions")

        # Create dependency edges
        for upstream, downstream, operator in SEED_DEPENDENCIES:
            edge = DependencyEdge(
                upstream_job_name=upstream,
                downstream_job_name=downstream,
                condition_operator=operator,
            )
            db.add(edge)
        await db.flush()
        print(f"Created {len(SEED_DEPENDENCIES)} dependency edges")

        # Create calendars
        today = date.today()
        cal = Calendar(
            name="WEEKDAYS",
            description="Standard weekday calendar (excludes weekends)",
            timezone="UTC",
            blackout_dates=[
                today + timedelta(days=i)
                for i in range(365)
                if (today + timedelta(days=i)).weekday() >= 5
            ],
        )
        db.add(cal)

        holidays = Calendar(
            name="US_HOLIDAYS_2026",
            description="US Federal Holidays 2026",
            timezone="America/New_York",
            blackout_dates=[
                date(2026, 1, 1),   # New Year
                date(2026, 1, 19),  # MLK Day
                date(2026, 2, 16),  # Presidents Day
                date(2026, 5, 25),  # Memorial Day
                date(2026, 7, 4),   # Independence Day
                date(2026, 9, 7),   # Labor Day
                date(2026, 11, 26), # Thanksgiving
                date(2026, 12, 25), # Christmas
            ],
        )
        db.add(holidays)
        await db.flush()
        print("Created calendars")

        await db.commit()
        print("Seed data committed successfully!")


if __name__ == "__main__":
    asyncio.run(seed())
