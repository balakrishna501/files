"""
WebSocket Connection Manager — real-time push to frontend clients.

Subscribes to the event bus and fans out all events to connected WebSocket clients.
No Redis pub/sub needed — PG LISTEN/NOTIFY + in-process fan-out handles it.
"""

import asyncio
import json
import logging
from typing import Any

from fastapi import WebSocket

logger = logging.getLogger("nexo.websocket")


class ConnectionManager:
    """Manages WebSocket connections and broadcasts events."""

    def __init__(self):
        self._connections: list[WebSocket] = []

    async def connect(self, websocket: WebSocket):
        """Accept and register a new WebSocket connection."""
        await websocket.accept()
        self._connections.append(websocket)
        logger.info(f"WebSocket connected. Total: {len(self._connections)}")

    def disconnect(self, websocket: WebSocket):
        """Remove a disconnected WebSocket."""
        self._connections = [c for c in self._connections if c != websocket]
        logger.info(f"WebSocket disconnected. Total: {len(self._connections)}")

    async def broadcast(self, message: dict[str, Any]):
        """Send a message to all connected clients."""
        if not self._connections:
            return

        payload = json.dumps(message, default=str)
        disconnected = []

        for ws in self._connections:
            try:
                await ws.send_text(payload)
            except Exception:
                disconnected.append(ws)

        for ws in disconnected:
            self.disconnect(ws)

    async def event_handler(self, event_data: dict[str, Any]):
        """Event bus subscriber callback — broadcasts events to all WS clients."""
        await self.broadcast({
            "type": "event",
            "data": event_data,
        })

    @property
    def connection_count(self) -> int:
        return len(self._connections)


# Singleton
ws_manager = ConnectionManager()
