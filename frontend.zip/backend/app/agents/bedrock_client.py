"""
AWS Bedrock Converse API client — wraps Claude Sonnet calls.

Uses Bedrock Converse API (not invoke_model) for structured tool use
and multi-turn conversation. Falls back to mock for local dev without AWS creds.
"""

import json
import logging
from typing import Any, Optional

from app.config import get_settings

logger = logging.getLogger("nexo.bedrock")

settings = get_settings()


class BedrockClient:
    """Wrapper around AWS Bedrock Converse API with Claude Sonnet."""

    def __init__(self):
        self._client = None
        self._mock_mode = False

    def _get_client(self):
        if self._client:
            return self._client

        try:
            import boto3
            self._client = boto3.client(
                "bedrock-runtime",
                region_name=settings.AWS_REGION,
                aws_access_key_id=settings.AWS_ACCESS_KEY_ID or None,
                aws_secret_access_key=settings.AWS_SECRET_ACCESS_KEY or None,
            )
            # Test connection
            logger.info(f"Bedrock client initialized (region={settings.AWS_REGION})")
            return self._client
        except Exception as e:
            logger.warning(f"Bedrock unavailable, using mock mode: {e}")
            self._mock_mode = True
            return None

    async def converse(
        self,
        messages: list[dict[str, Any]],
        system_prompt: Optional[str] = None,
        tools: Optional[list[dict]] = None,
        max_tokens: int = 4096,
        temperature: float = 0.3,
    ) -> dict[str, Any]:
        """
        Call Bedrock Converse API with Claude Sonnet.

        Args:
            messages: Conversation history [{role, content}]
            system_prompt: System instruction
            tools: Tool definitions for function calling
            max_tokens: Max response tokens
            temperature: Sampling temperature

        Returns:
            Full Converse API response dict
        """
        if self._mock_mode:
            return await self._mock_response(messages, system_prompt)

        client = self._get_client()
        if not client:
            return await self._mock_response(messages, system_prompt)

        try:
            # Build Converse API request
            converse_messages = []
            for msg in messages:
                converse_messages.append({
                    "role": msg["role"],
                    "content": [{"text": msg["content"]}],
                })

            kwargs = {
                "modelId": settings.BEDROCK_MODEL_ID,
                "messages": converse_messages,
                "inferenceConfig": {
                    "maxTokens": max_tokens,
                    "temperature": temperature,
                },
            }

            if system_prompt:
                kwargs["system"] = [{"text": system_prompt}]

            if tools:
                kwargs["toolConfig"] = {
                    "tools": tools,
                }

            response = client.converse(**kwargs)

            # Extract text from response
            output = response.get("output", {})
            message = output.get("message", {})

            return {
                "role": message.get("role", "assistant"),
                "content": self._extract_text(message),
                "tool_use": self._extract_tool_use(message),
                "stop_reason": response.get("stopReason", "end_turn"),
                "usage": response.get("usage", {}),
            }

        except Exception as e:
            logger.error(f"Bedrock Converse error: {e}")
            return await self._mock_response(messages, system_prompt)

    def _extract_text(self, message: dict) -> str:
        """Extract text content from Converse response message."""
        content = message.get("content", [])
        texts = []
        for block in content:
            if "text" in block:
                texts.append(block["text"])
        return "\n".join(texts)

    def _extract_tool_use(self, message: dict) -> Optional[list[dict]]:
        """Extract tool use blocks from Converse response."""
        content = message.get("content", [])
        tool_uses = []
        for block in content:
            if "toolUse" in block:
                tool_uses.append(block["toolUse"])
        return tool_uses if tool_uses else None

    async def _mock_response(
        self,
        messages: list[dict],
        system_prompt: Optional[str] = None,
    ) -> dict[str, Any]:
        """
        Mock response for local development without AWS credentials.
        Provides intelligent canned responses based on the prompt content.
        """
        last_message = messages[-1]["content"] if messages else ""
        prompt_lower = last_message.lower()

        # NL→JIL generation mock
        if any(kw in prompt_lower for kw in ["generate", "create job", "jil", "define"]):
            return {
                "role": "assistant",
                "content": json.dumps({
                    "interpreted_intent": f"Create job based on: {last_message}",
                    "jil": "insert_job: generated_job   job_type: CMD\ncommand: echo 'Generated by NEXO AI'\nstart_times: \"02:00\"\nalarm_if_fail: 1",
                    "job_definitions": [{
                        "job_name": "generated_job",
                        "job_type": "CMD",
                        "command": "echo 'Generated by NEXO AI'",
                        "start_times": "02:00",
                    }],
                    "warnings": ["Mock mode — connect AWS Bedrock for real AI generation"],
                    "confidence": 0.85,
                }),
                "tool_use": None,
                "stop_reason": "end_turn",
                "usage": {"inputTokens": 0, "outputTokens": 0},
            }

        # Failure analysis mock
        if any(kw in prompt_lower for kw in ["analyze", "failure", "error", "root cause"]):
            return {
                "role": "assistant",
                "content": json.dumps({
                    "root_cause": "Mock analysis: Job likely failed due to missing dependencies or resource constraints.",
                    "recommendations": [
                        "Check upstream job completion status",
                        "Verify resource availability on target machine",
                        "Review recent configuration changes",
                    ],
                    "suggested_remediation": "Retry with increased timeout",
                    "confidence": 0.7,
                }),
                "tool_use": None,
                "stop_reason": "end_turn",
                "usage": {"inputTokens": 0, "outputTokens": 0},
            }

        # Schedule optimization mock
        if any(kw in prompt_lower for kw in ["optimize", "schedule", "best time"]):
            return {
                "role": "assistant",
                "content": json.dumps({
                    "recommendation": "Based on historical patterns, optimal window is 02:00-04:00 UTC",
                    "reasoning": "Lowest resource contention, all upstream jobs typically complete by 01:45",
                    "suggested_cron": "0 2 * * 1-5",
                    "confidence": 0.75,
                }),
                "tool_use": None,
                "stop_reason": "end_turn",
                "usage": {"inputTokens": 0, "outputTokens": 0},
            }

        # Default chat response
        return {
            "role": "assistant",
            "content": (
                f"I'm the NEXO AI Assistant (mock mode). "
                f"I can help with job management, failure analysis, and schedule optimization. "
                f"Connect AWS Bedrock credentials for full AI capabilities. "
                f"Your question: {last_message}"
            ),
            "tool_use": None,
            "stop_reason": "end_turn",
            "usage": {"inputTokens": 0, "outputTokens": 0},
        }


# Singleton
bedrock_client = BedrockClient()
