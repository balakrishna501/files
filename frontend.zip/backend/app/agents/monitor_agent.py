"""
Monitor Agent — watches job streams for anomalies and raises intelligent alerts.

Subscribes to the event bus and analyzes:
1. Unexpected runtime durations (too fast / too slow)
2. Repeated failure patterns
3. SLA risk detection
4. Box job stalls
"""

import logging
from datetime import datetime, timedelta

from sqlalchemy import select, func, and_
from sqlalchemy.ext.asyncio import AsyncSession

from app.database import async_session_factory
from app.models.jobs import JobDefinition, JobRun
from app.models.alerts import Alert
from app.models.enums import JobStatus, EventType, AlertSeverity, AlertStatus
from app.events.event_bus import event_bus

logger = logging.getLogger("nexo.agents.monitor")


class MonitorAgent:
    """
    AI-powered monitoring agent that watches for anomalies.
    Subscribes to JOB_COMPLETED and JOB_FAILED events.
    """

    def __init__(self):
        self._started = False

    async def start(self):
        """Subscribe to relevant events."""
        if self._started:
            return
        event_bus.subscribe(EventType.JOB_COMPLETED, self._on_job_completed)
        event_bus.subscribe(EventType.JOB_FAILED, self._on_job_failed)
        self._started = True
        logger.info("Monitor agent started")

    async def _on_job_completed(self, event_data: dict):
        """Check for runtime anomalies on successful jobs."""
        job_name = event_data.get("job_name")
        if not job_name:
            return

        async with async_session_factory() as db:
            await self._check_runtime_anomaly(db, job_name)

    async def _on_job_failed(self, event_data: dict):
        """Analyze failure patterns and create alerts."""
        job_name = event_data.get("job_name")
        if not job_name:
            return

        async with async_session_factory() as db:
            await self._check_failure_pattern(db, job_name, event_data)

    async def _check_runtime_anomaly(self, db: AsyncSession, job_name: str):
        """Detect if a job ran significantly faster or slower than average."""
        result = await db.execute(
            select(JobRun.duration_seconds)
            .join(JobDefinition)
            .where(
                and_(
                    JobDefinition.job_name == job_name,
                    JobRun.status == JobStatus.SUCCESS,
                    JobRun.duration_seconds.isnot(None),
                )
            )
            .order_by(JobRun.created_at.desc())
            .limit(20)
        )
        durations = [row[0] for row in result if row[0] is not None]

        if len(durations) < 5:
            return  # Not enough history

        latest = durations[0]
        historical = durations[1:]
        avg = sum(historical) / len(historical)

        # Flag if >3x average or <0.1x average
        if latest > avg * 3:
            await self._create_alert(
                db, job_name,
                AlertSeverity.WARNING,
                f"Runtime anomaly: {job_name} took {latest:.0f}s (avg {avg:.0f}s)",
                f"Job ran {latest/avg:.1f}x slower than average. "
                f"Check for resource contention or data volume increase.",
            )
        elif avg > 0 and latest < avg * 0.1:
            await self._create_alert(
                db, job_name,
                AlertSeverity.WARNING,
                f"Runtime anomaly: {job_name} completed unusually fast ({latest:.0f}s vs avg {avg:.0f}s)",
                f"Job completed {avg/latest:.1f}x faster than normal. "
                f"Possible empty dataset or early exit without processing.",
            )

    async def _check_failure_pattern(
        self, db: AsyncSession, job_name: str, event_data: dict
    ):
        """Detect repeated failures and escalate."""
        since = datetime.utcnow() - timedelta(hours=4)
        result = await db.execute(
            select(func.count(JobRun.id))
            .join(JobDefinition)
            .where(
                and_(
                    JobDefinition.job_name == job_name,
                    JobRun.status == JobStatus.FAILURE,
                    JobRun.created_at >= since,
                )
            )
        )
        failure_count = result.scalar() or 0

        if failure_count >= 3:
            severity = AlertSeverity.CRITICAL
            title = f"Repeated failures: {job_name} failed {failure_count}x in 4 hours"
        else:
            severity = AlertSeverity.WARNING
            title = f"Job failed: {job_name}"

        exit_code = event_data.get("detail", {}).get("exit_code")
        desc = f"Exit code: {exit_code}" if exit_code else "No exit code available"

        await self._create_alert(db, job_name, severity, title, desc)

    async def _create_alert(
        self,
        db: AsyncSession,
        job_name: str,
        severity: AlertSeverity,
        title: str,
        description: str,
    ):
        """Create an alert and request AI analysis."""
        # Check for duplicate open alerts
        existing = await db.execute(
            select(Alert).where(
                and_(
                    Alert.job_name == job_name,
                    Alert.status.in_([AlertStatus.OPEN, AlertStatus.ACKNOWLEDGED]),
                    Alert.title == title,
                )
            )
        )
        if existing.scalar_one_or_none():
            return  # Avoid duplicate alerts

        # Get AI analysis
        ai_analysis = None
        try:
            from app.agents.orchestrator import orchestrator_agent
            analysis = await orchestrator_agent.analyze_failure(job_name, None, db)
            ai_analysis = analysis.root_cause
        except Exception as e:
            logger.warning(f"AI analysis failed: {e}")

        alert = Alert(
            job_name=job_name,
            severity=severity,
            title=title,
            description=description,
            ai_analysis=ai_analysis,
        )
        db.add(alert)
        await db.commit()
        logger.info(f"Alert created: [{severity.value}] {title}")


# Singleton
monitor_agent = MonitorAgent()
