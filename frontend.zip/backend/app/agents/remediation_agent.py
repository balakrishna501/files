"""
Remediation Agent — autonomous failure recovery.

Actions:
1. Retry with backoff
2. Reroute to alternate worker
3. Escalate to operator
4. Execute runbook actions
"""

import logging
from datetime import datetime

from sqlalchemy import select, and_
from sqlalchemy.ext.asyncio import AsyncSession

from app.database import async_session_factory
from app.models.jobs import JobDefinition, JobRun
from app.models.alerts import Alert
from app.models.enums import JobStatus, EventType, AlertStatus, AlertSeverity
from app.events.event_bus import event_bus

logger = logging.getLogger("nexo.agents.remediation")


class RemediationAgent:
    """
    Autonomous remediation agent — reacts to alerts and takes corrective action.
    """

    def __init__(self):
        self._started = False

    async def start(self):
        """Subscribe to alert events."""
        if self._started:
            return
        event_bus.subscribe(EventType.ALERT_RAISED, self._on_alert)
        self._started = True
        logger.info("Remediation agent started")

    async def _on_alert(self, event_data: dict):
        """React to raised alerts with automatic remediation."""
        job_name = event_data.get("job_name")
        if not job_name:
            return

        async with async_session_factory() as db:
            await self._attempt_remediation(db, job_name, event_data)

    async def _attempt_remediation(
        self, db: AsyncSession, job_name: str, event_data: dict
    ):
        """Determine and execute the best remediation action."""
        # Get job definition
        result = await db.execute(
            select(JobDefinition).where(JobDefinition.job_name == job_name)
        )
        job = result.scalar_one_or_none()
        if not job:
            return

        # Get the latest failed run
        run_result = await db.execute(
            select(JobRun)
            .where(
                and_(
                    JobRun.job_id == job.id,
                    JobRun.status == JobStatus.FAILURE,
                )
            )
            .order_by(JobRun.created_at.desc())
            .limit(1)
        )
        failed_run = run_result.scalar_one_or_none()
        if not failed_run:
            return

        # Decision tree for remediation
        action_taken = None

        # Strategy 1: Auto-retry if retries not exhausted
        if failed_run.retry_attempt < job.max_retries:
            logger.info(f"Remediation: auto-retrying {job_name}")
            action_taken = f"Auto-retry triggered (attempt {failed_run.retry_attempt + 1}/{job.max_retries})"
            # Execution engine handles retries internally

        # Strategy 2: Hold and escalate for repeated failures
        elif failed_run.retry_attempt >= job.max_retries and job.auto_hold_on_failure:
            from app.core.execution_engine import execution_engine
            await execution_engine.hold_job(db, job_name)
            action_taken = f"Job placed ON_HOLD after {job.max_retries} failed retries. Requires manual intervention."

        # Strategy 3: Log for operator review
        else:
            action_taken = "Failure logged. No automatic remediation available — manual review required."

        # Update the alert with remediation action
        if action_taken:
            alert_result = await db.execute(
                select(Alert)
                .where(
                    and_(
                        Alert.job_name == job_name,
                        Alert.status == AlertStatus.OPEN,
                    )
                )
                .order_by(Alert.created_at.desc())
                .limit(1)
            )
            alert = alert_result.scalar_one_or_none()
            if alert:
                alert.remediation_action = action_taken
                alert.status = AlertStatus.ACKNOWLEDGED

            await db.commit()

            # Publish remediation event
            await event_bus.publish(
                event_type=EventType.REMEDIATION_TRIGGERED,
                source="remediation_agent",
                job_name=job_name,
                detail={
                    "action": action_taken,
                    "run_id": str(failed_run.id),
                },
            )
            logger.info(f"Remediation for {job_name}: {action_taken}")

    async def remediate_by_alert_id(self, db: AsyncSession, alert_id) -> str:
        """Manual trigger — remediate a specific alert."""
        result = await db.execute(select(Alert).where(Alert.id == alert_id))
        alert = result.scalar_one_or_none()
        if not alert:
            return "Alert not found"

        if alert.job_name:
            await self._attempt_remediation(
                db, alert.job_name, {"job_name": alert.job_name}
            )
            return f"Remediation attempted for {alert.job_name}"

        return "No job associated with this alert"


# Singleton
remediation_agent = RemediationAgent()
