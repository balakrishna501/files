"""
LangGraph Agent Tools — functions that AI agents can invoke.
Each tool wraps a core engine capability for agent use.
"""

import json
from typing import Any
from sqlalchemy import select
from app.database import async_session_factory
from app.models.jobs import JobDefinition, JobRun
from app.models.enums import JobStatus, JobType


async def tool_list_jobs(filters: dict[str, Any] = None) -> str:
    """List jobs with optional filters. Returns JSON."""
    async with async_session_factory() as db:
        query = select(JobDefinition)
        if filters:
            if filters.get("job_type"):
                query = query.where(JobDefinition.job_type == filters["job_type"])
            if filters.get("box_name"):
                query = query.where(JobDefinition.box_name == filters["box_name"])
            if filters.get("search"):
                query = query.where(JobDefinition.job_name.ilike(f"%{filters['search']}%"))
        query = query.limit(50)
        result = await db.execute(query)
        jobs = result.scalars().all()
        return json.dumps([
            {"job_name": j.job_name, "job_type": j.job_type.value, "is_active": j.is_active}
            for j in jobs
        ])


async def tool_get_job_detail(job_name: str) -> str:
    """Get full details of a specific job."""
    async with async_session_factory() as db:
        result = await db.execute(
            select(JobDefinition).where(JobDefinition.job_name == job_name)
        )
        job = result.scalar_one_or_none()
        if not job:
            return json.dumps({"error": f"Job '{job_name}' not found"})
        return json.dumps({
            "job_name": job.job_name,
            "job_type": job.job_type.value,
            "command": job.command,
            "machine": job.machine,
            "condition": job.condition,
            "start_times": job.start_times,
            "cron_expression": job.cron_expression,
            "max_retries": job.max_retries,
            "description": job.description,
        })


async def tool_get_job_runs(job_name: str, limit: int = 10) -> str:
    """Get recent run history for a job."""
    async with async_session_factory() as db:
        result = await db.execute(
            select(JobRun)
            .join(JobDefinition)
            .where(JobDefinition.job_name == job_name)
            .order_by(JobRun.created_at.desc())
            .limit(limit)
        )
        runs = result.scalars().all()
        return json.dumps([
            {
                "run_number": r.run_number,
                "status": r.status.value,
                "exit_code": r.exit_code,
                "start_time": r.start_time.isoformat() if r.start_time else None,
                "end_time": r.end_time.isoformat() if r.end_time else None,
                "duration_seconds": r.duration_seconds,
                "stderr_tail": r.stderr_tail[:500] if r.stderr_tail else None,
            }
            for r in runs
        ])


async def tool_trigger_job(job_name: str, force: bool = False) -> str:
    """Trigger a job run."""
    from app.core.execution_engine import execution_engine
    async with async_session_factory() as db:
        try:
            run = await execution_engine.trigger_job(
                db, job_name, triggered_by="ai_agent", force=force
            )
            return json.dumps({
                "status": "triggered",
                "run_id": str(run.id),
                "job_name": job_name,
            })
        except ValueError as e:
            return json.dumps({"error": str(e)})


async def tool_get_dependencies(job_name: str) -> str:
    """Get dependency information for a job."""
    from app.core.dependency_manager import dependency_manager
    async with async_session_factory() as db:
        graph = await dependency_manager.build_graph(db)
        return json.dumps({
            "upstream": dependency_manager.get_upstream(graph, job_name),
            "downstream": dependency_manager.get_downstream(graph, job_name),
            "critical_path": dependency_manager.get_critical_path(graph, job_name),
        })


async def tool_hold_job(job_name: str) -> str:
    """Put a job on hold."""
    from app.core.execution_engine import execution_engine
    async with async_session_factory() as db:
        await execution_engine.hold_job(db, job_name)
        return json.dumps({"status": "held", "job_name": job_name})


async def tool_release_job(job_name: str) -> str:
    """Release a held job."""
    from app.core.execution_engine import execution_engine
    async with async_session_factory() as db:
        await execution_engine.release_hold(db, job_name)
        return json.dumps({"status": "released", "job_name": job_name})


# Tool definitions for Bedrock Converse API
BEDROCK_TOOLS = [
    {
        "toolSpec": {
            "name": "list_jobs",
            "description": "List job definitions with optional filters",
            "inputSchema": {
                "json": {
                    "type": "object",
                    "properties": {
                        "search": {"type": "string", "description": "Search job names"},
                        "job_type": {"type": "string", "enum": ["CMD", "BOX", "FW"]},
                    },
                }
            },
        }
    },
    {
        "toolSpec": {
            "name": "get_job_detail",
            "description": "Get full details of a specific job by name",
            "inputSchema": {
                "json": {
                    "type": "object",
                    "properties": {
                        "job_name": {"type": "string", "description": "The job name"},
                    },
                    "required": ["job_name"],
                }
            },
        }
    },
    {
        "toolSpec": {
            "name": "get_job_runs",
            "description": "Get recent run history and status for a job",
            "inputSchema": {
                "json": {
                    "type": "object",
                    "properties": {
                        "job_name": {"type": "string"},
                        "limit": {"type": "integer", "default": 10},
                    },
                    "required": ["job_name"],
                }
            },
        }
    },
    {
        "toolSpec": {
            "name": "trigger_job",
            "description": "Trigger a job to run immediately",
            "inputSchema": {
                "json": {
                    "type": "object",
                    "properties": {
                        "job_name": {"type": "string"},
                        "force": {"type": "boolean", "default": False},
                    },
                    "required": ["job_name"],
                }
            },
        }
    },
    {
        "toolSpec": {
            "name": "get_dependencies",
            "description": "Get upstream/downstream dependencies and critical path for a job",
            "inputSchema": {
                "json": {
                    "type": "object",
                    "properties": {
                        "job_name": {"type": "string"},
                    },
                    "required": ["job_name"],
                }
            },
        }
    },
    {
        "toolSpec": {
            "name": "hold_job",
            "description": "Put a job on hold to prevent it from running",
            "inputSchema": {
                "json": {
                    "type": "object",
                    "properties": {
                        "job_name": {"type": "string"},
                    },
                    "required": ["job_name"],
                }
            },
        }
    },
]

# Map tool names to functions
TOOL_FUNCTIONS = {
    "list_jobs": tool_list_jobs,
    "get_job_detail": tool_get_job_detail,
    "get_job_runs": tool_get_job_runs,
    "trigger_job": tool_trigger_job,
    "get_dependencies": tool_get_dependencies,
    "hold_job": tool_hold_job,
    "release_job": tool_release_job,
}
