"""
LangGraph Orchestrator Agent — the master brain that coordinates all AI operations.

Uses a LangGraph StateGraph to:
1. Route incoming requests to the right sub-agent
2. Manage multi-step reasoning with tool calls
3. Coordinate between Scheduler, Monitor, and Remediation agents

Falls back to direct Bedrock Converse API calls when LangGraph
adds unnecessary complexity for simple queries.
"""

import json
import logging
from typing import Any, Optional, TypedDict, Annotated
from uuid import UUID
from operator import add

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.agents.bedrock_client import bedrock_client
from app.agents.tools import BEDROCK_TOOLS, TOOL_FUNCTIONS
from app.models.jobs import JobDefinition, JobRun
from app.models.enums import JobStatus
from app.schemas.ai import NLJobResponse, AIAnalysisResponse, ChatResponse

logger = logging.getLogger("nexo.agents.orchestrator")

# ── System prompts ───────────────────────────────────────────────

SYSTEM_PROMPT = """You are NEXO AI, an intelligent workload automation assistant.
You are an expert in job scheduling, dependency management, and operational automation.
You help users manage their batch processing jobs — similar to CA AutoSys.

Your capabilities:
1. Generate job definitions from natural language descriptions
2. Analyze job failures and suggest root causes
3. Optimize job schedules based on historical patterns
4. Monitor job health and recommend remediation actions
5. Answer questions about job dependencies, schedules, and status

When generating job definitions, output valid JIL (Job Information Language) syntax.
Always consider dependencies, scheduling windows, and failure handling.
Be concise and actionable in your responses."""

NL_TO_JIL_PROMPT = """You are a JIL (Job Information Language) expert. Convert the user's natural language
description into valid AutoSys-compatible JIL definitions.

Rules:
- job_name must be alphanumeric with underscores, max 255 chars
- job_type is CMD, BOX, or FW
- conditions use: s(job_name) for success, f(job_name) for failure, d(job_name) for done
- start_times format: "HH:MM"
- days_of_week format: "mo,tu,we,th,fr"

Respond ONLY with valid JSON in this exact format:
{
    "interpreted_intent": "what you understood",
    "jil": "the full JIL text",
    "job_definitions": [{"job_name": "...", "job_type": "...", ...}],
    "warnings": ["any warnings"],
    "confidence": 0.0-1.0
}"""

FAILURE_ANALYSIS_PROMPT = """You are an expert SRE analyzing a job failure.
Given the job definition and recent run history, provide:
1. Root cause analysis
2. Specific recommendations to fix the issue
3. Suggested automated remediation if possible

Respond ONLY with valid JSON:
{
    "root_cause": "detailed analysis",
    "recommendations": ["action 1", "action 2"],
    "suggested_remediation": "auto-fix if applicable or null",
    "confidence": 0.0-1.0
}"""


class OrchestratorAgent:
    """Master agent that coordinates all AI operations in NEXO."""

    async def generate_job(self, prompt: str, db: AsyncSession) -> NLJobResponse:
        """Convert natural language to JIL job definitions."""
        # Gather context — existing jobs for reference
        result = await db.execute(
            select(JobDefinition.job_name, JobDefinition.job_type)
            .limit(50)
        )
        existing_jobs = [
            {"name": name, "type": jt.value}
            for name, jt in result
        ]

        context_msg = ""
        if existing_jobs:
            context_msg = f"\n\nExisting jobs in the system for reference:\n{json.dumps(existing_jobs)}"

        messages = [
            {"role": "user", "content": f"{prompt}{context_msg}"},
        ]

        response = await bedrock_client.converse(
            messages=messages,
            system_prompt=NL_TO_JIL_PROMPT,
            temperature=0.2,
        )

        try:
            parsed = json.loads(response["content"])
            return NLJobResponse(
                interpreted_intent=parsed.get("interpreted_intent", prompt),
                generated_jil=parsed.get("jil", ""),
                job_definitions=parsed.get("job_definitions", []),
                warnings=parsed.get("warnings", []),
                confidence=parsed.get("confidence", 0.5),
            )
        except (json.JSONDecodeError, KeyError):
            return NLJobResponse(
                interpreted_intent=prompt,
                generated_jil="",
                job_definitions=[],
                warnings=["Failed to parse AI response — raw: " + response["content"][:200]],
                confidence=0.0,
            )

    async def analyze_failure(
        self,
        job_name: str,
        run_id: Optional[UUID],
        db: AsyncSession,
    ) -> AIAnalysisResponse:
        """AI-powered root cause analysis for job failures."""
        # Gather context
        job_result = await db.execute(
            select(JobDefinition).where(JobDefinition.job_name == job_name)
        )
        job = job_result.scalar_one_or_none()
        if not job:
            return AIAnalysisResponse(
                root_cause=f"Job '{job_name}' not found",
                recommendations=["Verify the job name"],
                confidence=0.0,
            )

        # Get recent runs
        runs_query = (
            select(JobRun)
            .where(JobRun.job_id == job.id)
            .order_by(JobRun.created_at.desc())
            .limit(10)
        )
        if run_id:
            runs_query = select(JobRun).where(JobRun.id == run_id)

        runs_result = await db.execute(runs_query)
        runs = runs_result.scalars().all()

        run_data = [
            {
                "run_number": r.run_number,
                "status": r.status.value,
                "exit_code": r.exit_code,
                "duration": r.duration_seconds,
                "stderr": r.stderr_tail[:500] if r.stderr_tail else None,
                "start_time": r.start_time.isoformat() if r.start_time else None,
            }
            for r in runs
        ]

        context = json.dumps({
            "job_name": job.job_name,
            "job_type": job.job_type.value,
            "command": job.command,
            "machine": job.machine,
            "condition": job.condition,
            "max_retries": job.max_retries,
            "recent_runs": run_data,
        }, indent=2)

        messages = [
            {"role": "user", "content": f"Analyze this job failure:\n\n{context}"},
        ]

        response = await bedrock_client.converse(
            messages=messages,
            system_prompt=FAILURE_ANALYSIS_PROMPT,
            temperature=0.3,
        )

        try:
            parsed = json.loads(response["content"])
            return AIAnalysisResponse(
                root_cause=parsed.get("root_cause", "Unable to determine"),
                recommendations=parsed.get("recommendations", []),
                suggested_remediation=parsed.get("suggested_remediation"),
                confidence=parsed.get("confidence", 0.5),
            )
        except (json.JSONDecodeError, KeyError):
            return AIAnalysisResponse(
                root_cause=response["content"][:500],
                recommendations=["Review the raw AI output above"],
                confidence=0.3,
            )

    async def chat(
        self,
        messages: list[dict],
        context: Optional[dict],
        db: AsyncSession,
    ) -> ChatResponse:
        """Interactive chat with tool-calling capabilities."""
        # Convert messages to Bedrock format
        bedrock_messages = [
            {"role": msg["role"], "content": msg["content"]}
            for msg in messages
        ]

        # First call — may produce tool_use
        response = await bedrock_client.converse(
            messages=bedrock_messages,
            system_prompt=SYSTEM_PROMPT,
            tools=BEDROCK_TOOLS,
            temperature=0.4,
        )

        actions_taken = []

        # Handle tool calls
        if response.get("tool_use"):
            for tool_call in response["tool_use"]:
                tool_name = tool_call.get("name", "")
                tool_input = tool_call.get("input", {})

                if tool_name in TOOL_FUNCTIONS:
                    logger.info(f"Agent calling tool: {tool_name}({tool_input})")
                    tool_result = await TOOL_FUNCTIONS[tool_name](**tool_input)
                    actions_taken.append(f"Called {tool_name}")

                    # Follow-up call with tool result
                    bedrock_messages.append({
                        "role": "assistant",
                        "content": response["content"],
                    })
                    bedrock_messages.append({
                        "role": "user",
                        "content": f"Tool result for {tool_name}: {tool_result}",
                    })

                    response = await bedrock_client.converse(
                        messages=bedrock_messages,
                        system_prompt=SYSTEM_PROMPT,
                        temperature=0.4,
                    )

        return ChatResponse(
            response=response["content"],
            actions_taken=actions_taken,
            suggestions=[],
        )


# Singleton
orchestrator_agent = OrchestratorAgent()
