"""NEXO Configuration — all settings from environment variables."""

from pydantic_settings import BaseSettings
from functools import lru_cache


class Settings(BaseSettings):
    # ── Application ──────────────────────────────────────────────
    APP_NAME: str = "NEXO"
    APP_VERSION: str = "1.0.0"
    DEBUG: bool = True
    HOST: str = "0.0.0.0"
    PORT: int = 8000

    # ── PostgreSQL (single data store) ───────────────────────────
    DATABASE_URL: str = "postgresql+asyncpg://nexo:nexo_secret@localhost:5432/nexo"
    DATABASE_URL_SYNC: str = "postgresql+psycopg2://nexo:nexo_secret@localhost:5432/nexo"
    DB_POOL_SIZE: int = 20
    DB_MAX_OVERFLOW: int = 10
    DB_POOL_RECYCLE: int = 300

    # ── AWS Bedrock (Claude Sonnet) ──────────────────────────────
    AWS_REGION: str = "us-east-1"
    AWS_ACCESS_KEY_ID: str = ""
    AWS_SECRET_ACCESS_KEY: str = ""
    BEDROCK_MODEL_ID: str = "anthropic.claude-sonnet-4-20250514"

    # ── Event Bus (local mode simulates EventBridge via PG) ──────
    EVENT_BUS_MODE: str = "local"  # "local" | "eventbridge"

    # ── Execution ────────────────────────────────────────────────
    MAX_CONCURRENT_JOBS: int = 50
    JOB_DEFAULT_TIMEOUT: int = 3600  # seconds
    WORKER_HEARTBEAT_INTERVAL: int = 30  # seconds
    WORKER_COUNT: int = 4

    # ── WebSocket ────────────────────────────────────────────────
    WS_HEARTBEAT_INTERVAL: int = 15

    # ── Auth (simple JWT — no Keycloak) ──────────────────────────
    SECRET_KEY: str = "nexo-dev-secret-change-in-prod"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 480

    class Config:
        env_file = ".env"
        env_file_encoding = "utf-8"


@lru_cache()
def get_settings() -> Settings:
    return Settings()
