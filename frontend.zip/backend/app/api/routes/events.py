"""
Events & Alerts API — event history, alerts CRUD, alert actions.
"""

from datetime import datetime, timedelta
from typing import Optional
from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy import select, update
from sqlalchemy.ext.asyncio import AsyncSession

from app.database import get_db
from app.models.events import EventLog
from app.models.alerts import Alert
from app.models.enums import EventType, AlertSeverity, AlertStatus
from app.schemas.events import (
    EventPublish,
    EventResponse,
    AlertCreate,
    AlertResponse,
    AlertAction,
)
from app.events.event_bus import event_bus

router = APIRouter(prefix="/api", tags=["Events & Alerts"])


# ── Events ───────────────────────────────────────────────────────

@router.get("/events", response_model=list[EventResponse])
async def list_events(
    event_type: Optional[EventType] = None,
    job_name: Optional[str] = None,
    hours: int = Query(default=24, le=168),
    limit: int = Query(default=50, le=500),
    db: AsyncSession = Depends(get_db),
):
    """Get recent events with optional filters."""
    since = datetime.utcnow() - timedelta(hours=hours)
    query = select(EventLog).where(EventLog.created_at >= since)

    if event_type:
        query = query.where(EventLog.event_type == event_type)
    if job_name:
        query = query.where(EventLog.job_name == job_name)

    query = query.order_by(EventLog.created_at.desc()).limit(limit)
    result = await db.execute(query)
    return result.scalars().all()


@router.post("/events", response_model=EventResponse, status_code=201)
async def publish_event(
    event: EventPublish,
    db: AsyncSession = Depends(get_db),
):
    """Manually publish an event to the bus."""
    event_id = await event_bus.publish(
        event_type=event.event_type,
        source=event.source,
        detail=event.detail,
        job_name=event.job_name,
        detail_type=event.detail_type,
        correlation_id=event.correlation_id,
    )
    result = await db.execute(select(EventLog).where(EventLog.id == event_id))
    return result.scalar_one()


# ── Alerts ───────────────────────────────────────────────────────

@router.get("/alerts", response_model=list[AlertResponse])
async def list_alerts(
    status: Optional[AlertStatus] = None,
    severity: Optional[AlertSeverity] = None,
    job_name: Optional[str] = None,
    limit: int = Query(default=50, le=200),
    db: AsyncSession = Depends(get_db),
):
    """List alerts with filters."""
    query = select(Alert)
    if status:
        query = query.where(Alert.status == status)
    if severity:
        query = query.where(Alert.severity == severity)
    if job_name:
        query = query.where(Alert.job_name == job_name)

    query = query.order_by(Alert.created_at.desc()).limit(limit)
    result = await db.execute(query)
    return result.scalars().all()


@router.post("/alerts", response_model=AlertResponse, status_code=201)
async def create_alert(
    alert_data: AlertCreate,
    db: AsyncSession = Depends(get_db),
):
    """Create a new alert."""
    alert = Alert(**alert_data.model_dump())
    db.add(alert)
    await db.flush()
    return alert


@router.post("/alerts/{alert_id}/action", response_model=AlertResponse)
async def alert_action(
    alert_id: UUID,
    action: AlertAction,
    db: AsyncSession = Depends(get_db),
):
    """Perform an action on an alert (acknowledge, resolve, escalate, remediate)."""
    result = await db.execute(select(Alert).where(Alert.id == alert_id))
    alert = result.scalar_one_or_none()
    if not alert:
        raise HTTPException(404, "Alert not found")

    if action.action == "acknowledge":
        alert.status = AlertStatus.ACKNOWLEDGED
        alert.acknowledged_by = action.user
    elif action.action == "resolve":
        alert.status = AlertStatus.RESOLVED
        alert.resolved_at = datetime.utcnow()
    elif action.action == "escalate":
        alert.status = AlertStatus.ESCALATED
    elif action.action == "remediate":
        alert.status = AlertStatus.ACKNOWLEDGED
        alert.remediation_action = action.notes
    else:
        raise HTTPException(400, f"Unknown action: {action.action}")

    await db.flush()
    return alert
