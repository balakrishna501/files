"""Calendar API — named calendars with blackout dates."""

from uuid import UUID
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.database import get_db
from app.models.calendars import Calendar
from app.schemas.calendars import CalendarCreate, CalendarUpdate, CalendarResponse

router = APIRouter(prefix="/api/calendars", tags=["Calendars"])


@router.get("", response_model=list[CalendarResponse])
async def list_calendars(db: AsyncSession = Depends(get_db)):
    result = await db.execute(select(Calendar).order_by(Calendar.name))
    return result.scalars().all()


@router.post("", response_model=CalendarResponse, status_code=201)
async def create_calendar(data: CalendarCreate, db: AsyncSession = Depends(get_db)):
    existing = await db.execute(select(Calendar).where(Calendar.name == data.name))
    if existing.scalar_one_or_none():
        raise HTTPException(409, f"Calendar '{data.name}' already exists")

    cal = Calendar(**data.model_dump())
    db.add(cal)
    await db.flush()
    return cal


@router.put("/{name}", response_model=CalendarResponse)
async def update_calendar(name: str, data: CalendarUpdate, db: AsyncSession = Depends(get_db)):
    result = await db.execute(select(Calendar).where(Calendar.name == name))
    cal = result.scalar_one_or_none()
    if not cal:
        raise HTTPException(404, f"Calendar '{name}' not found")

    for field, value in data.model_dump(exclude_unset=True).items():
        setattr(cal, field, value)
    await db.flush()
    return cal


@router.delete("/{name}", status_code=204)
async def delete_calendar(name: str, db: AsyncSession = Depends(get_db)):
    result = await db.execute(select(Calendar).where(Calendar.name == name))
    cal = result.scalar_one_or_none()
    if not cal:
        raise HTTPException(404, f"Calendar '{name}' not found")
    await db.delete(cal)
