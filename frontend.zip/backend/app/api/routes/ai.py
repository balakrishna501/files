"""
AI Agent API — Natural language job authoring, failure analysis, chat.
Routes that invoke the LangGraph agent system.
"""

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession

from app.database import get_db
from app.schemas.ai import (
    NLJobRequest,
    NLJobResponse,
    AIAnalysisRequest,
    AIAnalysisResponse,
    ChatRequest,
    ChatResponse,
)

router = APIRouter(prefix="/api/ai", tags=["AI Agents"])


@router.post("/generate-job", response_model=NLJobResponse)
async def generate_job_from_nl(
    request: NLJobRequest,
    db: AsyncSession = Depends(get_db),
):
    """
    Generate job definitions from natural language.
    e.g. "Run payroll every weekday at 2am after GL_CLOSE succeeds"
    """
    from app.agents.orchestrator import orchestrator_agent
    result = await orchestrator_agent.generate_job(request.prompt, db)
    return result


@router.post("/analyze", response_model=AIAnalysisResponse)
async def analyze_failure(
    request: AIAnalysisRequest,
    db: AsyncSession = Depends(get_db),
):
    """AI-powered root cause analysis for job failures."""
    from app.agents.orchestrator import orchestrator_agent
    result = await orchestrator_agent.analyze_failure(
        request.job_name, request.run_id, db
    )
    return result


@router.post("/chat", response_model=ChatResponse)
async def chat(
    request: ChatRequest,
    db: AsyncSession = Depends(get_db),
):
    """Chat with the NEXO AI assistant — ask questions, get recommendations."""
    from app.agents.orchestrator import orchestrator_agent
    result = await orchestrator_agent.chat(request.messages, request.context, db)
    return result
