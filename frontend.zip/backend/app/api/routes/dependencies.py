"""
Dependency Graph API — DAG visualization, cycle detection, critical path.
"""

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession

from app.database import get_db
from app.core.dependency_manager import dependency_manager

router = APIRouter(prefix="/api/dependencies", tags=["Dependencies"])


@router.get("/graph")
async def get_full_graph(db: AsyncSession = Depends(get_db)):
    """Get the full dependency graph for React Flow visualization."""
    graph = await dependency_manager.build_graph(db)
    return dependency_manager.get_graph_data(graph)


@router.get("/{job_name}/upstream")
async def get_upstream(job_name: str, db: AsyncSession = Depends(get_db)):
    """Get direct upstream dependencies of a job."""
    graph = await dependency_manager.build_graph(db)
    return {"job_name": job_name, "upstream": dependency_manager.get_upstream(graph, job_name)}


@router.get("/{job_name}/downstream")
async def get_downstream(job_name: str, db: AsyncSession = Depends(get_db)):
    """Get direct downstream dependents of a job."""
    graph = await dependency_manager.build_graph(db)
    return {"job_name": job_name, "downstream": dependency_manager.get_downstream(graph, job_name)}


@router.get("/{job_name}/ancestors")
async def get_ancestors(job_name: str, db: AsyncSession = Depends(get_db)):
    """Get all transitive upstream jobs."""
    graph = await dependency_manager.build_graph(db)
    return {"job_name": job_name, "ancestors": list(dependency_manager.get_all_ancestors(graph, job_name))}


@router.get("/{job_name}/descendants")
async def get_descendants(job_name: str, db: AsyncSession = Depends(get_db)):
    """Get all transitive downstream jobs."""
    graph = await dependency_manager.build_graph(db)
    return {"job_name": job_name, "descendants": list(dependency_manager.get_all_descendants(graph, job_name))}


@router.get("/{job_name}/critical-path")
async def get_critical_path(job_name: str, db: AsyncSession = Depends(get_db)):
    """Get the critical path to a target job."""
    graph = await dependency_manager.build_graph(db)
    return {"job_name": job_name, "critical_path": dependency_manager.get_critical_path(graph, job_name)}


@router.get("/validate/cycles")
async def check_cycles(db: AsyncSession = Depends(get_db)):
    """Check the entire graph for cycles."""
    graph = await dependency_manager.build_graph(db)
    cycle = dependency_manager.detect_cycle(graph)
    return {"has_cycle": len(cycle) > 0, "cycle": cycle}


@router.get("/sort/topological")
async def topological_order(db: AsyncSession = Depends(get_db)):
    """Get jobs in topological (execution) order."""
    graph = await dependency_manager.build_graph(db)
    return {"order": dependency_manager.topological_sort(graph)}
