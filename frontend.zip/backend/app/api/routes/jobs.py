"""
Job Management API — CRUD, trigger, hold/release/kill, JIL import/export.
"""

from datetime import datetime, timedelta
from typing import Optional
from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy import select, func, and_, or_
from sqlalchemy.ext.asyncio import AsyncSession

from app.database import get_db
from app.models.jobs import JobDefinition, JobRun
from app.models.dependencies import DependencyEdge
from app.models.enums import JobType, JobStatus, EventType
from app.schemas.jobs import (
    JobDefinitionCreate,
    JobDefinitionUpdate,
    JobDefinitionResponse,
    JobRunResponse,
    JobRunTriggerRequest,
    JILImportRequest,
    JILExportResponse,
    DashboardStats,
)
from app.core.jil_parser import parse_jil, generate_jil, parse_condition
from app.core.dependency_manager import dependency_manager
from app.core.execution_engine import execution_engine
from app.core.audit_engine import audit_engine

router = APIRouter(prefix="/api/jobs", tags=["Jobs"])


# ── CRUD ─────────────────────────────────────────────────────────

@router.get("", response_model=list[JobDefinitionResponse])
async def list_jobs(
    job_type: Optional[JobType] = None,
    status: Optional[str] = None,
    search: Optional[str] = None,
    box_name: Optional[str] = None,
    is_active: Optional[bool] = True,
    offset: int = 0,
    limit: int = 100,
    db: AsyncSession = Depends(get_db),
):
    """List all job definitions with optional filters."""
    query = select(JobDefinition)

    if job_type:
        query = query.where(JobDefinition.job_type == job_type)
    if box_name:
        query = query.where(JobDefinition.box_name == box_name)
    if is_active is not None:
        query = query.where(JobDefinition.is_active == is_active)
    if search:
        query = query.where(JobDefinition.job_name.ilike(f"%{search}%"))

    query = query.order_by(JobDefinition.job_name).offset(offset).limit(limit)
    result = await db.execute(query)
    return result.scalars().all()


@router.get("/stats", response_model=DashboardStats)
async def get_dashboard_stats(db: AsyncSession = Depends(get_db)):
    """Dashboard statistics."""
    now = datetime.utcnow()
    day_ago = now - timedelta(hours=24)

    total = await db.execute(
        select(func.count(JobDefinition.id)).where(JobDefinition.is_active == True)
    )

    running = await db.execute(
        select(func.count(JobRun.id)).where(JobRun.status == JobStatus.RUNNING)
    )

    failed = await db.execute(
        select(func.count(JobRun.id)).where(
            and_(JobRun.status == JobStatus.FAILURE, JobRun.created_at >= day_ago)
        )
    )

    success = await db.execute(
        select(func.count(JobRun.id)).where(
            and_(JobRun.status == JobStatus.SUCCESS, JobRun.created_at >= day_ago)
        )
    )

    on_hold = await db.execute(
        select(func.count(JobRun.id)).where(JobRun.status == JobStatus.ON_HOLD)
    )

    return DashboardStats(
        total_jobs=total.scalar() or 0,
        running_now=running.scalar() or 0,
        failed_24h=failed.scalar() or 0,
        success_24h=success.scalar() or 0,
        on_hold=on_hold.scalar() or 0,
        sla_at_risk=0,
    )


@router.get("/{job_name}", response_model=JobDefinitionResponse)
async def get_job(job_name: str, db: AsyncSession = Depends(get_db)):
    """Get a single job definition by name."""
    result = await db.execute(
        select(JobDefinition).where(JobDefinition.job_name == job_name)
    )
    job = result.scalar_one_or_none()
    if not job:
        raise HTTPException(404, f"Job '{job_name}' not found")
    return job


@router.post("", response_model=JobDefinitionResponse, status_code=201)
async def create_job(
    job_data: JobDefinitionCreate,
    db: AsyncSession = Depends(get_db),
):
    """Create a new job definition."""
    # Check duplicate
    existing = await db.execute(
        select(JobDefinition).where(JobDefinition.job_name == job_data.job_name)
    )
    if existing.scalar_one_or_none():
        raise HTTPException(409, f"Job '{job_data.job_name}' already exists")

    # Validate box exists if specified
    if job_data.box_name:
        box = await db.execute(
            select(JobDefinition).where(
                JobDefinition.job_name == job_data.box_name,
                JobDefinition.job_type == JobType.BOX,
            )
        )
        if not box.scalar_one_or_none():
            raise HTTPException(400, f"Box '{job_data.box_name}' not found")

    job = JobDefinition(**job_data.model_dump())
    db.add(job)

    # Sync dependency edges if condition specified
    if job_data.condition:
        await db.flush()
        await dependency_manager.sync_dependencies(db, job_data.job_name, job_data.condition)

    await db.flush()

    # Audit
    await audit_engine.log(
        db, EventType.JOB_STATUS_CHANGED, "api",
        {"action": "create", "job_name": job_data.job_name},
        job_name=job_data.job_name,
    )

    return job


@router.put("/{job_name}", response_model=JobDefinitionResponse)
async def update_job(
    job_name: str,
    job_data: JobDefinitionUpdate,
    db: AsyncSession = Depends(get_db),
):
    """Update an existing job definition."""
    result = await db.execute(
        select(JobDefinition).where(JobDefinition.job_name == job_name)
    )
    job = result.scalar_one_or_none()
    if not job:
        raise HTTPException(404, f"Job '{job_name}' not found")

    update_data = job_data.model_dump(exclude_unset=True)
    for field, value in update_data.items():
        setattr(job, field, value)

    # Re-sync dependencies if condition changed
    if "condition" in update_data and update_data["condition"]:
        await dependency_manager.sync_dependencies(db, job_name, update_data["condition"])

    await db.flush()
    return job


@router.delete("/{job_name}", status_code=204)
async def delete_job(job_name: str, db: AsyncSession = Depends(get_db)):
    """Delete a job definition."""
    result = await db.execute(
        select(JobDefinition).where(JobDefinition.job_name == job_name)
    )
    job = result.scalar_one_or_none()
    if not job:
        raise HTTPException(404, f"Job '{job_name}' not found")

    await db.delete(job)


# ── Job Runs ─────────────────────────────────────────────────────

@router.get("/{job_name}/runs", response_model=list[JobRunResponse])
async def get_job_runs(
    job_name: str,
    limit: int = Query(default=20, le=100),
    db: AsyncSession = Depends(get_db),
):
    """Get run history for a job."""
    result = await db.execute(
        select(JobRun)
        .join(JobDefinition)
        .where(JobDefinition.job_name == job_name)
        .order_by(JobRun.created_at.desc())
        .limit(limit)
    )
    return result.scalars().all()


@router.get("/runs/active", response_model=list[JobRunResponse])
async def get_active_runs(db: AsyncSession = Depends(get_db)):
    """Get all currently running/starting jobs."""
    result = await db.execute(
        select(JobRun)
        .where(JobRun.status.in_([JobStatus.RUNNING, JobStatus.STARTING, JobStatus.QUE_WAIT]))
        .order_by(JobRun.start_time.desc())
    )
    return result.scalars().all()


# ── Actions ──────────────────────────────────────────────────────

@router.post("/{job_name}/trigger", response_model=JobRunResponse)
async def trigger_job(
    job_name: str,
    force: bool = Query(default=False),
    db: AsyncSession = Depends(get_db),
):
    """Manually trigger a job run."""
    try:
        run = await execution_engine.trigger_job(
            db, job_name, triggered_by="manual", force=force
        )
        return run
    except ValueError as e:
        raise HTTPException(400, str(e))


@router.post("/{job_name}/hold", status_code=200)
async def hold_job(job_name: str, db: AsyncSession = Depends(get_db)):
    """Put a job on hold."""
    await execution_engine.hold_job(db, job_name)
    return {"status": "held", "job_name": job_name}


@router.post("/{job_name}/release", status_code=200)
async def release_job(job_name: str, db: AsyncSession = Depends(get_db)):
    """Release a held job."""
    await execution_engine.release_hold(db, job_name)
    return {"status": "released", "job_name": job_name}


@router.post("/{job_name}/kill", status_code=200)
async def kill_job(job_name: str, db: AsyncSession = Depends(get_db)):
    """Kill a running job."""
    await execution_engine.kill_job(db, job_name)
    return {"status": "terminated", "job_name": job_name}


# ── JIL Import / Export ──────────────────────────────────────────

@router.post("/import/jil", status_code=201)
async def import_jil(
    request: JILImportRequest,
    db: AsyncSession = Depends(get_db),
):
    """Import jobs from JIL text — AutoSys migration path."""
    parsed_jobs = parse_jil(request.jil_text)
    created = []

    for job_data in parsed_jobs:
        job_name = job_data.get("job_name")
        if not job_name:
            continue

        # Check if exists
        existing = await db.execute(
            select(JobDefinition).where(JobDefinition.job_name == job_name)
        )
        if existing.scalar_one_or_none():
            continue  # skip existing

        # Map job_type string to enum
        jt = job_data.get("job_type", "CMD")
        job_data["job_type"] = JobType(jt)

        condition = job_data.pop("condition", None)
        job = JobDefinition(**job_data)
        db.add(job)
        await db.flush()

        if condition:
            job.condition = condition
            await dependency_manager.sync_dependencies(db, job_name, condition)

        created.append(job_name)

    return {"imported": len(created), "job_names": created}


@router.get("/{job_name}/jil", response_model=JILExportResponse)
async def export_jil(job_name: str, db: AsyncSession = Depends(get_db)):
    """Export a job as JIL text."""
    result = await db.execute(
        select(JobDefinition).where(JobDefinition.job_name == job_name)
    )
    job = result.scalar_one_or_none()
    if not job:
        raise HTTPException(404, f"Job '{job_name}' not found")

    job_dict = {
        c.key: getattr(job, c.key)
        for c in JobDefinition.__table__.columns
        if getattr(job, c.key) is not None
    }
    # Convert enums to strings
    if "job_type" in job_dict:
        job_dict["job_type"] = job_dict["job_type"].value

    return JILExportResponse(jil_text=generate_jil(job_dict))
