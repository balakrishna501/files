"""Schedule API — view upcoming schedule, Gantt data, calendar engine queries."""

from datetime import date, datetime
from typing import Optional

from fastapi import APIRouter, Depends, Query
from sqlalchemy.ext.asyncio import AsyncSession

from app.database import get_db
from app.core.calendar_engine import calendar_engine

router = APIRouter(prefix="/api/schedule", tags=["Schedule"])


@router.get("/today")
async def get_today_schedule(db: AsyncSession = Depends(get_db)):
    """Get all scheduled jobs for today."""
    return await calendar_engine.get_schedule_for_day(db, date.today())


@router.get("/date/{target_date}")
async def get_schedule_for_date(
    target_date: date,
    db: AsyncSession = Depends(get_db),
):
    """Get all scheduled jobs for a specific date."""
    return await calendar_engine.get_schedule_for_day(db, target_date)


@router.get("/gantt")
async def get_gantt_data(
    start_date: Optional[date] = None,
    end_date: Optional[date] = None,
    db: AsyncSession = Depends(get_db),
):
    """Get Gantt chart data for a date range."""
    from sqlalchemy import select, and_
    from app.models.jobs import JobRun, JobDefinition

    if not start_date:
        start_date = date.today()
    if not end_date:
        end_date = start_date

    start_dt = datetime.combine(start_date, datetime.min.time())
    end_dt = datetime.combine(end_date, datetime.max.time())

    result = await db.execute(
        select(JobRun, JobDefinition.job_name, JobDefinition.job_type)
        .join(JobDefinition, JobRun.job_id == JobDefinition.id)
        .where(
            and_(
                JobRun.scheduled_time >= start_dt,
                JobRun.scheduled_time <= end_dt,
            )
        )
        .order_by(JobRun.scheduled_time)
    )

    gantt_items = []
    for run, job_name, job_type in result:
        gantt_items.append({
            "id": str(run.id),
            "job_name": job_name,
            "job_type": job_type.value if job_type else "CMD",
            "status": run.status.value,
            "scheduled_time": run.scheduled_time.isoformat() if run.scheduled_time else None,
            "start_time": run.start_time.isoformat() if run.start_time else None,
            "end_time": run.end_time.isoformat() if run.end_time else None,
            "duration_seconds": run.duration_seconds,
        })

    return gantt_items
