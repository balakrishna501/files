"""
Local Event Bus — simulates AWS EventBridge using PostgreSQL LISTEN/NOTIFY.

In production, this would be swapped for real EventBridge via the adapter pattern.
Locally, PG LISTEN/NOTIFY provides sub-millisecond event delivery with zero
external dependencies.

Architecture:
  Publisher → PG NOTIFY → PG LISTEN → Subscriber callbacks
  Publisher → EventLog table (durable audit trail)
  WebSocket fan-out via subscriber callbacks
"""

import asyncio
import json
import logging
import uuid
from datetime import datetime
from typing import Any, Callable, Coroutine, Optional

import asyncpg
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.config import get_settings
from app.models.events import EventLog
from app.models.enums import EventType
from app.database import async_session_factory

logger = logging.getLogger("nexo.eventbus")

# Type alias for event handlers
EventHandler = Callable[[dict[str, Any]], Coroutine[Any, Any, None]]

PG_CHANNEL = "nexo_events"


class LocalEventBus:
    """
    PostgreSQL-backed event bus with LISTEN/NOTIFY for real-time delivery.
    Durable events stored in event_log table for replay and audit.
    """

    def __init__(self):
        self._subscribers: dict[EventType, list[EventHandler]] = {}
        self._global_subscribers: list[EventHandler] = []
        self._listener_task: Optional[asyncio.Task] = None
        self._conn: Optional[asyncpg.Connection] = None
        self._running = False

    def subscribe(self, event_type: EventType, handler: EventHandler):
        """Subscribe to a specific event type."""
        if event_type not in self._subscribers:
            self._subscribers[event_type] = []
        self._subscribers[event_type].append(handler)
        logger.debug(f"Subscriber added for {event_type.value}")

    def subscribe_all(self, handler: EventHandler):
        """Subscribe to ALL events (used by WebSocket fan-out)."""
        self._global_subscribers.append(handler)

    def unsubscribe_all_handler(self, handler: EventHandler):
        """Remove a global subscriber."""
        self._global_subscribers = [h for h in self._global_subscribers if h is not handler]

    async def publish(
        self,
        event_type: EventType,
        source: str,
        detail: dict[str, Any] = None,
        job_name: Optional[str] = None,
        detail_type: Optional[str] = None,
        correlation_id: Optional[uuid.UUID] = None,
    ) -> uuid.UUID:
        """
        Publish an event:
        1. Write to event_log table (durable)
        2. NOTIFY on PG channel (real-time)
        3. Invoke local subscribers (in-process)
        """
        detail = detail or {}
        event_id = uuid.uuid4()

        # 1. Persist to event_log
        async with async_session_factory() as db:
            event = EventLog(
                id=event_id,
                event_type=event_type,
                source=source,
                detail_type=detail_type,
                detail=detail,
                job_name=job_name,
                correlation_id=correlation_id,
            )
            db.add(event)
            await db.commit()

        # 2. PG NOTIFY for cross-process delivery
        payload = json.dumps({
            "id": str(event_id),
            "event_type": event_type.value,
            "source": source,
            "job_name": job_name,
            "detail": detail,
            "timestamp": datetime.utcnow().isoformat(),
        }, default=str)

        try:
            if self._conn and not self._conn.is_closed():
                await self._conn.execute(
                    f"SELECT pg_notify('{PG_CHANNEL}', $1)", payload
                )
        except Exception as e:
            logger.warning(f"PG NOTIFY failed (non-fatal): {e}")

        # 3. Local subscriber dispatch (fire-and-forget)
        event_data = {
            "id": str(event_id),
            "event_type": event_type.value,
            "source": source,
            "job_name": job_name,
            "detail": detail,
            "detail_type": detail_type,
            "correlation_id": str(correlation_id) if correlation_id else None,
            "timestamp": datetime.utcnow().isoformat(),
        }

        await self._dispatch(event_type, event_data)

        logger.debug(f"Event published: {event_type.value} for {job_name}")
        return event_id

    async def _dispatch(self, event_type: EventType, event_data: dict):
        """Dispatch event to all matching subscribers."""
        handlers = self._subscribers.get(event_type, []) + self._global_subscribers

        for handler in handlers:
            try:
                asyncio.create_task(handler(event_data))
            except Exception as e:
                logger.error(f"Event handler error: {e}")

    async def start_listener(self):
        """Start PG LISTEN for cross-process event delivery."""
        settings = get_settings()
        # Parse asyncpg connection string from SQLAlchemy URL
        dsn = settings.DATABASE_URL.replace("postgresql+asyncpg://", "postgresql://")

        try:
            self._conn = await asyncpg.connect(dsn)
            await self._conn.add_listener(PG_CHANNEL, self._pg_notification_handler)
            self._running = True
            logger.info(f"Event bus listening on PG channel: {PG_CHANNEL}")

            # Keep alive
            self._listener_task = asyncio.create_task(self._keep_alive())
        except Exception as e:
            logger.error(f"Failed to start event listener: {e}")

    def _pg_notification_handler(self, conn, pid, channel, payload):
        """Handle incoming PG NOTIFY — dispatch to subscribers."""
        try:
            data = json.loads(payload)
            event_type = EventType(data["event_type"])
            asyncio.create_task(self._dispatch(event_type, data))
        except Exception as e:
            logger.error(f"Error handling PG notification: {e}")

    async def _keep_alive(self):
        """Keep the listener connection alive."""
        while self._running:
            await asyncio.sleep(30)
            try:
                if self._conn and not self._conn.is_closed():
                    await self._conn.execute("SELECT 1")
            except Exception:
                logger.warning("Event bus keep-alive failed, reconnecting...")
                await self.start_listener()
                return

    async def stop(self):
        """Shutdown the event bus."""
        self._running = False
        if self._listener_task:
            self._listener_task.cancel()
        if self._conn and not self._conn.is_closed():
            await self._conn.close()
        logger.info("Event bus stopped")

    async def replay_events(
        self,
        db: AsyncSession,
        event_type: Optional[EventType] = None,
        since: Optional[datetime] = None,
        job_name: Optional[str] = None,
        limit: int = 100,
    ) -> list[dict]:
        """Replay events from the durable log (useful for recovery)."""
        query = select(EventLog)
        if event_type:
            query = query.where(EventLog.event_type == event_type)
        if since:
            query = query.where(EventLog.created_at >= since)
        if job_name:
            query = query.where(EventLog.job_name == job_name)

        query = query.order_by(EventLog.created_at.desc()).limit(limit)
        result = await db.execute(query)
        events = result.scalars().all()

        return [
            {
                "id": str(e.id),
                "event_type": e.event_type.value,
                "source": e.source,
                "job_name": e.job_name,
                "detail": e.detail,
                "created_at": e.created_at.isoformat(),
            }
            for e in events
        ]


# Singleton
event_bus = LocalEventBus()
