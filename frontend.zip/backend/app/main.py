"""
NEXO — Main FastAPI Application
In-house AutoSys replica with AI Agentic System.
"""

import logging
from contextlib import asynccontextmanager

from fastapi import FastAPI, WebSocket, WebSocketDisconnect
from fastapi.middleware.cors import CORSMiddleware

from app.config import get_settings
from app.database import init_db, dispose_db
from app.events.event_bus import event_bus
from app.websocket.manager import ws_manager
from app.core.scheduler import nexo_scheduler
from app.api.routes import jobs, dependencies, events, calendars, ai, schedule
from app.agents.monitor_agent import monitor_agent
from app.agents.remediation_agent import remediation_agent

settings = get_settings()

# ── Logging ──────────────────────────────────────────────────────
logging.basicConfig(
    level=logging.DEBUG if settings.DEBUG else logging.INFO,
    format="%(asctime)s [%(name)s] %(levelname)s: %(message)s",
)
logger = logging.getLogger("nexo")


# ── Lifespan ─────────────────────────────────────────────────────
@asynccontextmanager
async def lifespan(app: FastAPI):
    """Startup/shutdown lifecycle."""
    logger.info("🚀 NEXO starting up...")

    # 1. Init database tables
    await init_db()
    logger.info("Database initialized")

    # 2. Start event bus listener
    await event_bus.start_listener()
    event_bus.subscribe_all(ws_manager.event_handler)
    logger.info("Event bus started")

    # 3. Start job scheduler
    await nexo_scheduler.start()
    logger.info("Scheduler started")

    # 4. Start AI agents
    await monitor_agent.start()
    await remediation_agent.start()
    logger.info("AI agents started")

    logger.info(f"NEXO v{settings.APP_VERSION} ready on port {settings.PORT}")

    yield

    # Shutdown
    logger.info("NEXO shutting down...")
    await nexo_scheduler.stop()
    await event_bus.stop()
    await dispose_db()
    logger.info("NEXO stopped")


# ── App ──────────────────────────────────────────────────────────
app = FastAPI(
    title="NEXO",
    description="In-house AutoSys replica with AI Agentic System",
    version=settings.APP_VERSION,
    lifespan=lifespan,
)

# CORS for React frontend
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5173", "http://localhost:3000"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# ── Routes ───────────────────────────────────────────────────────
app.include_router(jobs.router)
app.include_router(dependencies.router)
app.include_router(events.router)
app.include_router(calendars.router)
app.include_router(ai.router)
app.include_router(schedule.router)


# ── WebSocket ────────────────────────────────────────────────────
@app.websocket("/ws")
async def websocket_endpoint(websocket: WebSocket):
    """Real-time event stream for the frontend."""
    await ws_manager.connect(websocket)
    try:
        while True:
            # Keep connection alive, handle client messages
            data = await websocket.receive_text()
            # Client can send ping/subscribe messages if needed
    except WebSocketDisconnect:
        ws_manager.disconnect(websocket)


# ── Health ───────────────────────────────────────────────────────
@app.get("/health")
async def health():
    return {
        "status": "healthy",
        "version": settings.APP_VERSION,
        "ws_connections": ws_manager.connection_count,
    }


@app.get("/")
async def root():
    return {
        "name": "NEXO",
        "version": settings.APP_VERSION,
        "description": "In-house AutoSys replica with AI Agentic System",
        "docs": "/docs",
    }
