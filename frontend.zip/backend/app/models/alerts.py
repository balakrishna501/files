"""Alert model — AI monitor agent findings and operator escalations."""

import uuid
from datetime import datetime
from sqlalchemy import Column, String, Text, DateTime, ForeignKey, Index, Enum as SAEnum
from sqlalchemy.dialects.postgresql import UUID, JSONB
from app.database import Base
from app.models.enums import AlertSeverity, AlertStatus


class Alert(Base):
    """Alerts raised by the Monitor Agent or threshold breaches."""
    __tablename__ = "alerts"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    job_name = Column(String(255), ForeignKey("job_definitions.job_name"), nullable=True)
    run_id = Column(UUID(as_uuid=True), ForeignKey("job_runs.id"), nullable=True)

    severity = Column(SAEnum(AlertSeverity, name="alert_severity_enum"), nullable=False)
    status = Column(SAEnum(AlertStatus, name="alert_status_enum"), default=AlertStatus.OPEN)

    title = Column(String(512), nullable=False)
    description = Column(Text, nullable=True)
    ai_analysis = Column(Text, nullable=True)        # AI-generated root cause analysis
    remediation_action = Column(Text, nullable=True)  # what the Remediation Agent did

    metadata_ = Column("metadata", JSONB, default=dict)

    acknowledged_by = Column(String(128), nullable=True)
    resolved_at = Column(DateTime, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    __table_args__ = (
        Index("ix_alert_status", "status"),
        Index("ix_alert_severity_status", "severity", "status"),
        Index("ix_alert_job", "job_name"),
        Index("ix_alert_created", "created_at"),
    )
