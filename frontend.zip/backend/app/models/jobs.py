"""Job definition and run history models — AutoSys JIL-compatible schema."""

import uuid
from datetime import datetime
from sqlalchemy import (
    Column, String, Text, Integer, Float, Boolean, DateTime,
    ForeignKey, Index, CheckConstraint, UniqueConstraint, JSON,
    Enum as SAEnum,
)
from sqlalchemy.dialects.postgresql import UUID, ARRAY
from sqlalchemy.orm import relationship
from app.database import Base
from app.models.enums import JobType, JobStatus


class JobDefinition(Base):
    """
    Core job definition — equivalent to AutoSys JIL.
    Stores the *template* of a job, not a specific run.
    """
    __tablename__ = "job_definitions"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    job_name = Column(String(255), unique=True, nullable=False, index=True)
    job_type = Column(SAEnum(JobType, name="job_type_enum"), nullable=False)

    # ── Command / execution details ──────────────────────────────
    command = Column(Text, nullable=True)          # CMD jobs
    machine = Column(String(255), nullable=True)   # target host
    owner = Column(String(128), nullable=True)
    permission = Column(String(64), nullable=True)
    profile = Column(Text, nullable=True)          # shell profile to source
    std_out_file = Column(Text, nullable=True)
    std_err_file = Column(Text, nullable=True)

    # ── Box membership ───────────────────────────────────────────
    box_name = Column(String(255), ForeignKey("job_definitions.job_name"), nullable=True)

    # ── Scheduling (cron-style) ──────────────────────────────────
    start_times = Column(String(512), nullable=True)   # "02:00, 14:00"
    start_mins = Column(String(128), nullable=True)    # cron minute field
    start_days = Column(String(128), nullable=True)    # "mo,tu,we,th,fr"
    run_calendar = Column(String(255), nullable=True)  # named calendar
    exclude_calendar = Column(String(255), nullable=True)
    timezone = Column(String(64), default="UTC")
    cron_expression = Column(String(128), nullable=True)  # full cron if provided

    # ── Conditions / Dependencies (JIL condition string) ─────────
    condition = Column(Text, nullable=True)  # e.g. "s(job_a) & s(job_b)"

    # ── Alarms & thresholds ──────────────────────────────────────
    alarm_if_fail = Column(Boolean, default=True)
    alarm_if_terminated = Column(Boolean, default=True)
    max_run_alarm = Column(Integer, nullable=True)     # minutes
    min_run_alarm = Column(Integer, nullable=True)     # minutes
    max_exit_success = Column(Integer, default=0)

    # ── File Watcher specifics ───────────────────────────────────
    watch_file = Column(Text, nullable=True)
    watch_file_min_size = Column(Integer, nullable=True)  # bytes
    watch_interval = Column(Integer, default=60)          # seconds

    # ── Retry / auto-remediation ─────────────────────────────────
    max_retries = Column(Integer, default=0)
    retry_interval = Column(Integer, default=300)  # seconds between retries
    auto_hold_on_failure = Column(Boolean, default=False)

    # ── Metadata ─────────────────────────────────────────────────
    description = Column(Text, nullable=True)
    tags = Column(ARRAY(String), default=list)
    priority = Column(Integer, default=0)
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    # ── Relationships ────────────────────────────────────────────
    runs = relationship("JobRun", back_populates="job_definition", lazy="dynamic")
    children = relationship(
        "JobDefinition",
        backref="parent_box",
        remote_side="JobDefinition.job_name",
        foreign_keys=[box_name],
    )

    __table_args__ = (
        Index("ix_job_def_box", "box_name"),
        Index("ix_job_def_type", "job_type"),
        Index("ix_job_def_tags", "tags", postgresql_using="gin"),
        Index("ix_job_def_name_trgm", "job_name", postgresql_using="gin",
              postgresql_ops={"job_name": "gin_trgm_ops"}),
    )

    def __repr__(self):
        return f"<Job {self.job_name} ({self.job_type.value})>"


class JobRun(Base):
    """
    Immutable record of a single job execution.
    New row per run — never updated after terminal state.
    """
    __tablename__ = "job_runs"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    job_id = Column(UUID(as_uuid=True), ForeignKey("job_definitions.id"), nullable=False)
    run_number = Column(Integer, nullable=False)

    status = Column(SAEnum(JobStatus, name="job_status_enum"), default=JobStatus.INACTIVE)
    exit_code = Column(Integer, nullable=True)

    # ── Timing ───────────────────────────────────────────────────
    scheduled_time = Column(DateTime, nullable=True)
    start_time = Column(DateTime, nullable=True)
    end_time = Column(DateTime, nullable=True)
    duration_seconds = Column(Float, nullable=True)

    # ── Execution context ────────────────────────────────────────
    machine = Column(String(255), nullable=True)
    pid = Column(Integer, nullable=True)
    worker_id = Column(String(128), nullable=True)
    retry_attempt = Column(Integer, default=0)

    # ── Output capture ───────────────────────────────────────────
    stdout_tail = Column(Text, nullable=True)  # last 4KB of stdout
    stderr_tail = Column(Text, nullable=True)  # last 4KB of stderr

    # ── Metadata ─────────────────────────────────────────────────
    triggered_by = Column(String(128), nullable=True)  # "schedule", "manual", "dependency", "agent"
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    # ── Relationships ────────────────────────────────────────────
    job_definition = relationship("JobDefinition", back_populates="runs")

    __table_args__ = (
        Index("ix_job_run_job_id", "job_id"),
        Index("ix_job_run_status", "status"),
        Index("ix_job_run_start_time", "start_time"),
        Index("ix_job_run_composite", "job_id", "status", "start_time"),
        UniqueConstraint("job_id", "run_number", name="uq_job_run_number"),
    )

    def __repr__(self):
        return f"<JobRun {self.id} status={self.status.value}>"
