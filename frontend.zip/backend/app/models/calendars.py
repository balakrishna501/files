"""Calendar model — named calendars with blackout dates (holiday support)."""

import uuid
from datetime import date, datetime
from sqlalchemy import Column, String, Date, Boolean, DateTime, Index
from sqlalchemy.dialects.postgresql import UUID, ARRAY
from app.database import Base


class Calendar(Base):
    """Named calendar for scheduling — supports blackout dates and custom run days."""
    __tablename__ = "calendars"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    name = Column(String(255), unique=True, nullable=False)
    description = Column(String(512), nullable=True)
    timezone = Column(String(64), default="UTC")

    # Store dates as arrays — PostgreSQL ARRAY is fast for membership checks
    run_dates = Column(ARRAY(Date), default=list)       # explicit run dates
    blackout_dates = Column(ARRAY(Date), default=list)   # holidays / no-run dates

    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    __table_args__ = (
        Index("ix_calendar_name", "name"),
    )
