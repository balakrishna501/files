"""Event log model — immutable event store (local EventBridge simulation)."""

import uuid
from datetime import datetime
from sqlalchemy import Column, String, Text, DateTime, Index, Enum as SAEnum
from sqlalchemy.dialects.postgresql import UUID, JSONB
from app.database import Base
from app.models.enums import EventType


class EventLog(Base):
    """
    Every state transition, trigger, and agent action is logged here.
    This is the local EventBridge equivalent — PG LISTEN/NOTIFY drives real-time,
    this table provides durable replay and audit.
    """
    __tablename__ = "event_log"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    event_type = Column(SAEnum(EventType, name="event_type_enum"), nullable=False)
    source = Column(String(255), nullable=False)   # "scheduler", "monitor_agent", "user:john"
    detail_type = Column(String(255), nullable=True)
    detail = Column(JSONB, nullable=False, default=dict)
    job_name = Column(String(255), nullable=True, index=True)
    correlation_id = Column(UUID(as_uuid=True), nullable=True)  # trace across related events
    created_at = Column(DateTime, default=datetime.utcnow, index=True)

    __table_args__ = (
        Index("ix_event_type_time", "event_type", "created_at"),
        Index("ix_event_correlation", "correlation_id"),
        Index("ix_event_detail", "detail", postgresql_using="gin"),
    )
