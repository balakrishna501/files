"""NEXO domain enums — mirrors AutoSys job types and states."""

import enum


class JobType(str, enum.Enum):
    """AutoSys-compatible job types."""
    CMD = "CMD"          # Command job — runs a shell command
    BOX = "BOX"          # Box job — container for child jobs
    FW = "FW"            # File Watcher — triggers on file arrival
    FTP = "FTP"          # FTP job — file transfer


class JobStatus(str, enum.Enum):
    """Job run state machine: mirrors AutoSys statuses."""
    INACTIVE = "INACTIVE"
    ACTIVATED = "ACTIVATED"
    STARTING = "STARTING"
    RUNNING = "RUNNING"
    SUCCESS = "SUCCESS"
    FAILURE = "FAILURE"
    TERMINATED = "TERMINATED"
    RESTART = "RESTART"
    ON_HOLD = "ON_HOLD"
    ON_ICE = "ON_ICE"
    QUE_WAIT = "QUE_WAIT"


class ConditionOperator(str, enum.Enum):
    """Dependency condition operators."""
    SUCCESS = "s"        # success(job_name)
    FAILURE = "f"        # failure(job_name)
    DONE = "d"           # done(job_name) — success or failure
    NOTRUNNING = "n"     # notrunning(job_name)


class EventType(str, enum.Enum):
    """Internal event bus event types."""
    JOB_STARTED = "JOB_STARTED"
    JOB_COMPLETED = "JOB_COMPLETED"
    JOB_FAILED = "JOB_FAILED"
    JOB_STATUS_CHANGED = "JOB_STATUS_CHANGED"
    DEPENDENCY_MET = "DEPENDENCY_MET"
    FILE_ARRIVED = "FILE_ARRIVED"
    SCHEDULE_TRIGGERED = "SCHEDULE_TRIGGERED"
    ALERT_RAISED = "ALERT_RAISED"
    AGENT_ACTION = "AGENT_ACTION"
    REMEDIATION_TRIGGERED = "REMEDIATION_TRIGGERED"


class AlertSeverity(str, enum.Enum):
    INFO = "INFO"
    WARNING = "WARNING"
    CRITICAL = "CRITICAL"


class AlertStatus(str, enum.Enum):
    OPEN = "OPEN"
    ACKNOWLEDGED = "ACKNOWLEDGED"
    RESOLVED = "RESOLVED"
    ESCALATED = "ESCALATED"
