"""Dependency edge model — DAG edges between jobs."""

import uuid
from datetime import datetime
from sqlalchemy import Column, String, ForeignKey, DateTime, Index, Enum as SAEnum
from sqlalchemy.dialects.postgresql import UUID
from app.database import Base
from app.models.enums import ConditionOperator


class DependencyEdge(Base):
    """
    Explicit dependency edge: upstream_job → downstream_job.
    Parsed from JIL condition strings and stored for fast DAG traversal.
    """
    __tablename__ = "dependency_edges"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    upstream_job_name = Column(
        String(255),
        ForeignKey("job_definitions.job_name", ondelete="CASCADE"),
        nullable=False,
    )
    downstream_job_name = Column(
        String(255),
        ForeignKey("job_definitions.job_name", ondelete="CASCADE"),
        nullable=False,
    )
    condition_operator = Column(
        SAEnum(ConditionOperator, name="condition_op_enum"),
        default=ConditionOperator.SUCCESS,
    )
    created_at = Column(DateTime, default=datetime.utcnow)

    __table_args__ = (
        Index("ix_dep_upstream", "upstream_job_name"),
        Index("ix_dep_downstream", "downstream_job_name"),
        Index("ix_dep_pair", "upstream_job_name", "downstream_job_name", unique=True),
    )
