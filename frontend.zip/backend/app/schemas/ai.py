"""Pydantic schemas for AI Agent interactions."""

from __future__ import annotations
from typing import Optional, Any
from uuid import UUID
from pydantic import BaseModel


class NLJobRequest(BaseModel):
    """Natural language job authoring request."""
    prompt: str  # e.g. "Run payroll after GL close succeeds, every weekday at 2am"


class NLJobResponse(BaseModel):
    """AI-generated job definition from natural language."""
    interpreted_intent: str
    generated_jil: str
    job_definitions: list[dict[str, Any]]
    warnings: list[str] = []
    confidence: float


class AIAnalysisRequest(BaseModel):
    """Request AI analysis of a job failure or pattern."""
    job_name: str
    run_id: Optional[UUID] = None
    question: Optional[str] = None


class AIAnalysisResponse(BaseModel):
    root_cause: str
    recommendations: list[str]
    suggested_remediation: Optional[str] = None
    confidence: float


class ChatMessage(BaseModel):
    role: str  # "user" or "assistant"
    content: str


class ChatRequest(BaseModel):
    messages: list[ChatMessage]
    context: Optional[dict[str, Any]] = None


class ChatResponse(BaseModel):
    response: str
    actions_taken: list[str] = []
    suggestions: list[str] = []
