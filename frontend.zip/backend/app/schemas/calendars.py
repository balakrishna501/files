"""Pydantic schemas for Calendars."""

from __future__ import annotations
from datetime import date, datetime
from typing import Optional
from uuid import UUID
from pydantic import BaseModel


class CalendarCreate(BaseModel):
    name: str
    description: Optional[str] = None
    timezone: str = "UTC"
    run_dates: list[date] = []
    blackout_dates: list[date] = []


class CalendarUpdate(BaseModel):
    description: Optional[str] = None
    timezone: Optional[str] = None
    run_dates: Optional[list[date]] = None
    blackout_dates: Optional[list[date]] = None
    is_active: Optional[bool] = None


class CalendarResponse(BaseModel):
    id: UUID
    name: str
    description: Optional[str] = None
    timezone: str
    run_dates: list[date]
    blackout_dates: list[date]
    is_active: bool
    created_at: datetime

    class Config:
        from_attributes = True
