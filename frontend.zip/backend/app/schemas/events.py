"""Pydantic schemas for Events and Alerts."""

from __future__ import annotations
from datetime import datetime
from typing import Optional, Any
from uuid import UUID
from pydantic import BaseModel
from app.models.enums import EventType, AlertSeverity, AlertStatus


class EventPublish(BaseModel):
    event_type: EventType
    source: str
    detail_type: Optional[str] = None
    detail: dict[str, Any] = {}
    job_name: Optional[str] = None
    correlation_id: Optional[UUID] = None


class EventResponse(BaseModel):
    id: UUID
    event_type: EventType
    source: str
    detail_type: Optional[str] = None
    detail: dict[str, Any]
    job_name: Optional[str] = None
    correlation_id: Optional[UUID] = None
    created_at: datetime

    class Config:
        from_attributes = True


class AlertCreate(BaseModel):
    job_name: Optional[str] = None
    run_id: Optional[UUID] = None
    severity: AlertSeverity
    title: str
    description: Optional[str] = None
    ai_analysis: Optional[str] = None


class AlertResponse(BaseModel):
    id: UUID
    job_name: Optional[str] = None
    run_id: Optional[UUID] = None
    severity: AlertSeverity
    status: AlertStatus
    title: str
    description: Optional[str] = None
    ai_analysis: Optional[str] = None
    remediation_action: Optional[str] = None
    acknowledged_by: Optional[str] = None
    resolved_at: Optional[datetime] = None
    created_at: datetime

    class Config:
        from_attributes = True


class AlertAction(BaseModel):
    action: str  # "acknowledge", "resolve", "escalate", "remediate"
    user: Optional[str] = None
    notes: Optional[str] = None
