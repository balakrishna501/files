"""Pydantic schemas for Job Definition and Job Run — request/response validation."""

from __future__ import annotations
from datetime import datetime
from typing import Optional
from uuid import UUID
from pydantic import BaseModel, Field, field_validator
from app.models.enums import JobType, JobStatus


# ── Job Definition ───────────────────────────────────────────────

class JobDefinitionBase(BaseModel):
    job_name: str = Field(..., min_length=1, max_length=255, pattern=r"^[a-zA-Z0-9_\-\.]+$")
    job_type: JobType
    command: Optional[str] = None
    machine: Optional[str] = None
    owner: Optional[str] = None
    profile: Optional[str] = None
    std_out_file: Optional[str] = None
    std_err_file: Optional[str] = None
    box_name: Optional[str] = None
    start_times: Optional[str] = None
    start_mins: Optional[str] = None
    start_days: Optional[str] = None
    run_calendar: Optional[str] = None
    exclude_calendar: Optional[str] = None
    timezone: str = "UTC"
    cron_expression: Optional[str] = None
    condition: Optional[str] = None
    alarm_if_fail: bool = True
    max_run_alarm: Optional[int] = None
    min_run_alarm: Optional[int] = None
    max_exit_success: int = 0
    watch_file: Optional[str] = None
    watch_file_min_size: Optional[int] = None
    watch_interval: int = 60
    max_retries: int = 0
    retry_interval: int = 300
    auto_hold_on_failure: bool = False
    description: Optional[str] = None
    tags: list[str] = Field(default_factory=list)
    priority: int = 0
    is_active: bool = True

    @field_validator("command")
    @classmethod
    def cmd_required_for_cmd_type(cls, v, info):
        if info.data.get("job_type") == JobType.CMD and not v:
            raise ValueError("command is required for CMD jobs")
        return v


class JobDefinitionCreate(JobDefinitionBase):
    pass


class JobDefinitionUpdate(BaseModel):
    """Partial update — all fields optional."""
    command: Optional[str] = None
    machine: Optional[str] = None
    owner: Optional[str] = None
    box_name: Optional[str] = None
    start_times: Optional[str] = None
    cron_expression: Optional[str] = None
    condition: Optional[str] = None
    max_run_alarm: Optional[int] = None
    max_retries: Optional[int] = None
    description: Optional[str] = None
    tags: Optional[list[str]] = None
    priority: Optional[int] = None
    is_active: Optional[bool] = None
    watch_file: Optional[str] = None
    timezone: Optional[str] = None
    start_days: Optional[str] = None
    run_calendar: Optional[str] = None
    exclude_calendar: Optional[str] = None
    profile: Optional[str] = None
    std_out_file: Optional[str] = None
    std_err_file: Optional[str] = None
    alarm_if_fail: Optional[bool] = None
    retry_interval: Optional[int] = None
    auto_hold_on_failure: Optional[bool] = None


class JobDefinitionResponse(JobDefinitionBase):
    id: UUID
    created_at: datetime
    updated_at: datetime

    class Config:
        from_attributes = True


# ── Job Run ──────────────────────────────────────────────────────

class JobRunResponse(BaseModel):
    id: UUID
    job_id: UUID
    run_number: int
    status: JobStatus
    exit_code: Optional[int] = None
    scheduled_time: Optional[datetime] = None
    start_time: Optional[datetime] = None
    end_time: Optional[datetime] = None
    duration_seconds: Optional[float] = None
    machine: Optional[str] = None
    worker_id: Optional[str] = None
    retry_attempt: int = 0
    stdout_tail: Optional[str] = None
    stderr_tail: Optional[str] = None
    triggered_by: Optional[str] = None
    created_at: datetime

    class Config:
        from_attributes = True


class JobRunTriggerRequest(BaseModel):
    """Manual trigger request."""
    job_name: str
    force: bool = False  # ignore conditions


# ── JIL Import/Export ────────────────────────────────────────────

class JILImportRequest(BaseModel):
    jil_text: str


class JILExportResponse(BaseModel):
    jil_text: str


# ── Dashboard Stats ──────────────────────────────────────────────

class DashboardStats(BaseModel):
    total_jobs: int
    running_now: int
    failed_24h: int
    success_24h: int
    on_hold: int
    sla_at_risk: int
