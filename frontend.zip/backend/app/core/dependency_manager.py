"""
Dependency Manager — DAG operations, cycle detection, topological sort,
and condition evaluation for job dependencies.

Uses NetworkX for graph algorithms + PostgreSQL for persistence.
"""

import re
from typing import Optional
from uuid import UUID

import networkx as nx
from sqlalchemy import select, delete
from sqlalchemy.ext.asyncio import AsyncSession

from app.models.jobs import JobDefinition, JobRun
from app.models.dependencies import DependencyEdge
from app.models.enums import ConditionOperator, JobStatus
from app.core.jil_parser import parse_condition


class DependencyManager:
    """Manages the job dependency DAG."""

    def __init__(self):
        self._graph: Optional[nx.DiGraph] = None

    async def build_graph(self, db: AsyncSession) -> nx.DiGraph:
        """Load all edges from DB and build an in-memory NetworkX DAG."""
        result = await db.execute(select(DependencyEdge))
        edges = result.scalars().all()

        G = nx.DiGraph()
        # Add all jobs as nodes
        job_result = await db.execute(select(JobDefinition.job_name))
        for (name,) in job_result:
            G.add_node(name)

        # Add dependency edges
        for edge in edges:
            G.add_edge(
                edge.upstream_job_name,
                edge.downstream_job_name,
                condition=edge.condition_operator.value,
            )

        self._graph = G
        return G

    async def sync_dependencies(self, db: AsyncSession, job_name: str, condition_str: str):
        """
        Parse a condition string and sync dependency edges to DB.
        Replaces all existing downstream edges for this job.
        """
        # Delete existing edges where this job is downstream
        await db.execute(
            delete(DependencyEdge).where(
                DependencyEdge.downstream_job_name == job_name
            )
        )

        # Parse and insert new edges
        deps = parse_condition(condition_str)
        for dep in deps:
            edge = DependencyEdge(
                upstream_job_name=dep["job_name"],
                downstream_job_name=job_name,
                condition_operator=ConditionOperator(dep["operator"]),
            )
            db.add(edge)

        await db.flush()

    def detect_cycle(self, graph: nx.DiGraph) -> list[str]:
        """Return cycle path if one exists, else empty list."""
        try:
            cycle = nx.find_cycle(graph, orientation="original")
            return [edge[0] for edge in cycle]
        except nx.NetworkXNoCycle:
            return []

    def would_create_cycle(
        self, graph: nx.DiGraph, upstream: str, downstream: str
    ) -> bool:
        """Check if adding an edge would create a cycle."""
        test_graph = graph.copy()
        test_graph.add_edge(upstream, downstream)
        return not nx.is_directed_acyclic_graph(test_graph)

    def topological_sort(self, graph: nx.DiGraph) -> list[str]:
        """Return jobs in execution order (topological sort)."""
        return list(nx.topological_sort(graph))

    def get_upstream(self, graph: nx.DiGraph, job_name: str) -> list[str]:
        """Get all direct upstream dependencies."""
        if job_name not in graph:
            return []
        return list(graph.predecessors(job_name))

    def get_downstream(self, graph: nx.DiGraph, job_name: str) -> list[str]:
        """Get all direct downstream dependents."""
        if job_name not in graph:
            return []
        return list(graph.successors(job_name))

    def get_all_ancestors(self, graph: nx.DiGraph, job_name: str) -> set[str]:
        """Get all transitive upstream jobs."""
        if job_name not in graph:
            return set()
        return nx.ancestors(graph, job_name)

    def get_all_descendants(self, graph: nx.DiGraph, job_name: str) -> set[str]:
        """Get all transitive downstream jobs."""
        if job_name not in graph:
            return set()
        return nx.descendants(graph, job_name)

    def get_critical_path(self, graph: nx.DiGraph, target_job: str) -> list[str]:
        """Get the longest path to the target job (critical path)."""
        if target_job not in graph:
            return []
        try:
            ancestors = nx.ancestors(graph, target_job)
            subgraph = graph.subgraph(ancestors | {target_job})
            return nx.dag_longest_path(subgraph)
        except (nx.NetworkXError, nx.NetworkXUnfeasible):
            return [target_job]

    def get_graph_data(self, graph: nx.DiGraph) -> dict:
        """Export graph as nodes + edges for frontend visualization."""
        nodes = []
        for node in graph.nodes():
            nodes.append({
                "id": node,
                "data": {"label": node},
                "position": {"x": 0, "y": 0},  # layout computed on frontend
            })

        edges = []
        for u, v, data in graph.edges(data=True):
            edges.append({
                "id": f"{u}->{v}",
                "source": u,
                "target": v,
                "label": data.get("condition", "s"),
            })

        return {"nodes": nodes, "edges": edges}

    async def evaluate_conditions(
        self, db: AsyncSession, job_name: str, condition_str: str
    ) -> bool:
        """
        Evaluate if a job's dependency conditions are met.
        Checks the latest run status of each upstream job.
        """
        if not condition_str:
            return True

        deps = parse_condition(condition_str)
        if not deps:
            return True

        for dep in deps:
            upstream_name = dep["job_name"]
            operator = dep["operator"]

            # Get the latest run of the upstream job
            result = await db.execute(
                select(JobRun)
                .join(JobDefinition)
                .where(JobDefinition.job_name == upstream_name)
                .order_by(JobRun.created_at.desc())
                .limit(1)
            )
            latest_run = result.scalar_one_or_none()

            if latest_run is None:
                return False

            if operator == "s" and latest_run.status != JobStatus.SUCCESS:
                return False
            elif operator == "f" and latest_run.status != JobStatus.FAILURE:
                return False
            elif operator == "d" and latest_run.status not in (
                JobStatus.SUCCESS, JobStatus.FAILURE
            ):
                return False
            elif operator == "n" and latest_run.status == JobStatus.RUNNING:
                return False

        return True


# Singleton
dependency_manager = DependencyManager()
