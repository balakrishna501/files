"""
Calendar Engine — schedule resolution, cron parsing, and blackout management.
Replaces APScheduler's calendar-aware scheduling with PostgreSQL-backed calendars.
"""

from datetime import datetime, date, timedelta, time
from typing import Optional
from zoneinfo import ZoneInfo

from croniter import croniter
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.models.jobs import JobDefinition
from app.models.calendars import Calendar


class CalendarEngine:
    """Resolves when jobs should fire based on cron, calendars, and time zones."""

    def parse_start_times(self, start_times_str: str) -> list[time]:
        """Parse AutoSys start_times format: '02:00, 14:00' → list of time objects."""
        if not start_times_str:
            return []
        times = []
        for part in start_times_str.split(","):
            part = part.strip().strip('"').strip("'")
            try:
                h, m = part.split(":")
                times.append(time(int(h), int(m)))
            except (ValueError, IndexError):
                continue
        return times

    def get_next_fire_time(
        self,
        cron_expression: Optional[str] = None,
        start_times: Optional[str] = None,
        start_days: Optional[str] = None,
        timezone: str = "UTC",
        base_time: Optional[datetime] = None,
    ) -> Optional[datetime]:
        """Calculate the next fire time from cron or start_times/start_days."""
        tz = ZoneInfo(timezone)
        now = base_time or datetime.now(tz)

        if cron_expression:
            cron = croniter(cron_expression, now)
            return cron.get_next(datetime)

        if start_times:
            parsed_times = self.parse_start_times(start_times)
            if not parsed_times:
                return None

            # Map day abbreviations to weekday numbers
            day_map = {"su": 6, "mo": 0, "tu": 1, "we": 2, "th": 3, "fr": 4, "sa": 5}
            allowed_days = None
            if start_days:
                allowed_days = set()
                for d in start_days.lower().replace(" ", "").split(","):
                    if d in day_map:
                        allowed_days.add(day_map[d])

            # Find next valid time
            for day_offset in range(8):  # check up to a week ahead
                candidate_date = now.date() + timedelta(days=day_offset)
                if allowed_days and candidate_date.weekday() not in allowed_days:
                    continue

                for t in sorted(parsed_times):
                    candidate = datetime.combine(candidate_date, t, tzinfo=tz)
                    if candidate > now:
                        return candidate

        return None

    async def is_blackout(
        self, db: AsyncSession, calendar_name: str, check_date: date
    ) -> bool:
        """Check if a date is blacked out in a named calendar."""
        result = await db.execute(
            select(Calendar).where(Calendar.name == calendar_name)
        )
        cal = result.scalar_one_or_none()
        if not cal:
            return False
        return check_date in (cal.blackout_dates or [])

    async def is_run_date(
        self, db: AsyncSession, calendar_name: str, check_date: date
    ) -> bool:
        """Check if a date is a valid run date in a named calendar."""
        result = await db.execute(
            select(Calendar).where(Calendar.name == calendar_name)
        )
        cal = result.scalar_one_or_none()
        if not cal:
            return True  # no calendar = always run
        if cal.run_dates:
            return check_date in cal.run_dates
        return True  # no explicit run_dates = always run (unless blacked out)

    async def should_run_today(
        self, db: AsyncSession, job: JobDefinition
    ) -> bool:
        """Determine if a job should run today considering all calendar rules."""
        today = date.today()

        # Check exclude calendar
        if job.exclude_calendar:
            if await self.is_blackout(db, job.exclude_calendar, today):
                return False

        # Check run calendar
        if job.run_calendar:
            if not await self.is_run_date(db, job.run_calendar, today):
                return False

        return True

    async def get_schedule_for_day(
        self, db: AsyncSession, target_date: date
    ) -> list[dict]:
        """Get all scheduled jobs and their fire times for a given date."""
        result = await db.execute(
            select(JobDefinition).where(
                JobDefinition.is_active == True,
                JobDefinition.job_type != "BOX",
            )
        )
        jobs = result.scalars().all()

        schedule = []
        for job in jobs:
            if not job.start_times and not job.cron_expression:
                continue

            fire_time = self.get_next_fire_time(
                cron_expression=job.cron_expression,
                start_times=job.start_times,
                start_days=job.start_days,
                timezone=job.timezone or "UTC",
            )

            if fire_time and fire_time.date() == target_date:
                schedule.append({
                    "job_name": job.job_name,
                    "job_type": job.job_type.value,
                    "fire_time": fire_time.isoformat(),
                    "timezone": job.timezone,
                })

        return sorted(schedule, key=lambda x: x["fire_time"])


# Singleton
calendar_engine = CalendarEngine()
