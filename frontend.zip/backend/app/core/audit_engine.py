"""
Audit Engine — immutable audit trail for all job operations.
Every create, update, delete, trigger, and status change is logged.
"""

import logging
from datetime import datetime, timedelta
from typing import Optional, Any
from uuid import UUID

from sqlalchemy import select, func, and_
from sqlalchemy.ext.asyncio import AsyncSession

from app.models.events import EventLog
from app.models.enums import EventType

logger = logging.getLogger("nexo.audit")


class AuditEngine:
    """Provides immutable audit logging and query capabilities."""

    async def log(
        self,
        db: AsyncSession,
        event_type: EventType,
        source: str,
        detail: dict[str, Any],
        job_name: Optional[str] = None,
        correlation_id: Optional[UUID] = None,
    ):
        """Write an immutable audit event."""
        event = EventLog(
            event_type=event_type,
            source=source,
            detail=detail,
            job_name=job_name,
            correlation_id=correlation_id,
        )
        db.add(event)
        await db.flush()
        return event

    async def get_job_history(
        self,
        db: AsyncSession,
        job_name: str,
        limit: int = 100,
        offset: int = 0,
    ) -> list[EventLog]:
        """Get audit trail for a specific job."""
        result = await db.execute(
            select(EventLog)
            .where(EventLog.job_name == job_name)
            .order_by(EventLog.created_at.desc())
            .offset(offset)
            .limit(limit)
        )
        return result.scalars().all()

    async def get_events_by_type(
        self,
        db: AsyncSession,
        event_type: EventType,
        since: Optional[datetime] = None,
        limit: int = 100,
    ) -> list[EventLog]:
        """Get events of a specific type."""
        query = select(EventLog).where(EventLog.event_type == event_type)
        if since:
            query = query.where(EventLog.created_at >= since)
        query = query.order_by(EventLog.created_at.desc()).limit(limit)

        result = await db.execute(query)
        return result.scalars().all()

    async def get_recent_activity(
        self,
        db: AsyncSession,
        limit: int = 50,
    ) -> list[EventLog]:
        """Get the most recent events across all jobs."""
        result = await db.execute(
            select(EventLog)
            .order_by(EventLog.created_at.desc())
            .limit(limit)
        )
        return result.scalars().all()

    async def get_failure_stats(
        self,
        db: AsyncSession,
        hours: int = 24,
    ) -> dict:
        """Get failure statistics for the given time window."""
        since = datetime.utcnow() - timedelta(hours=hours)

        result = await db.execute(
            select(
                EventLog.job_name,
                func.count(EventLog.id).label("failure_count"),
            )
            .where(
                and_(
                    EventLog.event_type == EventType.JOB_FAILED,
                    EventLog.created_at >= since,
                )
            )
            .group_by(EventLog.job_name)
            .order_by(func.count(EventLog.id).desc())
        )

        return {
            "period_hours": hours,
            "failures": [
                {"job_name": row.job_name, "count": row.failure_count}
                for row in result
            ],
        }

    async def get_correlation_trail(
        self,
        db: AsyncSession,
        correlation_id: UUID,
    ) -> list[EventLog]:
        """Get all events for a correlation ID (trace a single execution chain)."""
        result = await db.execute(
            select(EventLog)
            .where(EventLog.correlation_id == correlation_id)
            .order_by(EventLog.created_at.asc())
        )
        return result.scalars().all()


# Singleton
audit_engine = AuditEngine()
