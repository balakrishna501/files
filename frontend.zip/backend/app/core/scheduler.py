"""
Job Scheduler — background loop that fires jobs at their scheduled times.

Uses APScheduler for cron-trigger management + CalendarEngine for date validation.
All state in PostgreSQL, no Redis needed.
"""

import asyncio
import logging
from datetime import datetime, timedelta

from apscheduler.schedulers.asyncio import AsyncIOScheduler
from apscheduler.triggers.cron import CronTrigger
from sqlalchemy import select

from app.database import async_session_factory
from app.models.jobs import JobDefinition
from app.models.enums import JobType
from app.core.calendar_engine import calendar_engine
from app.core.execution_engine import execution_engine

logger = logging.getLogger("nexo.scheduler")


class NexoScheduler:
    """Manages all cron-based and time-based job scheduling."""

    def __init__(self):
        self._scheduler = AsyncIOScheduler()
        self._scheduled_jobs: set[str] = set()

    async def start(self):
        """Load all active jobs and start the scheduler."""
        logger.info("Starting NEXO scheduler...")
        self._scheduler.start()
        await self._load_all_jobs()

        # Periodic re-sync every 60s to pick up new/changed job definitions
        self._scheduler.add_job(
            self._load_all_jobs,
            "interval",
            seconds=60,
            id="__nexo_resync__",
            replace_existing=True,
        )
        logger.info("NEXO scheduler started")

    async def stop(self):
        """Shutdown the scheduler gracefully."""
        self._scheduler.shutdown(wait=False)
        logger.info("NEXO scheduler stopped")

    async def _load_all_jobs(self):
        """Sync all active job schedules from the database."""
        async with async_session_factory() as db:
            result = await db.execute(
                select(JobDefinition).where(
                    JobDefinition.is_active == True,
                )
            )
            jobs = result.scalars().all()

            for job in jobs:
                if job.cron_expression or job.start_times:
                    await self._schedule_job(db, job)

    async def _schedule_job(self, db, job: JobDefinition):
        """Add or update a job's schedule in APScheduler."""
        scheduler_id = f"nexo_{job.job_name}"

        if scheduler_id in self._scheduled_jobs:
            return  # Already scheduled

        try:
            if job.cron_expression:
                trigger = CronTrigger.from_crontab(
                    job.cron_expression,
                )
            elif job.start_times:
                # Convert start_times to cron: "02:00, 14:00" → run at those hours
                times = calendar_engine.parse_start_times(job.start_times)
                if not times:
                    return

                hours = ",".join(str(t.hour) for t in times)
                minutes = ",".join(str(t.minute) for t in times)

                # Add day-of-week if specified
                dow = "*"
                if job.start_days:
                    dow = job.start_days.lower()

                trigger = CronTrigger(
                    minute=minutes,
                    hour=hours,
                    day_of_week=dow,
                )
            else:
                return

            self._scheduler.add_job(
                self._fire_job,
                trigger=trigger,
                args=[job.job_name],
                id=scheduler_id,
                replace_existing=True,
                misfire_grace_time=300,
            )
            self._scheduled_jobs.add(scheduler_id)
            logger.info(f"Scheduled job: {job.job_name}")

        except Exception as e:
            logger.error(f"Failed to schedule {job.job_name}: {e}")

    async def _fire_job(self, job_name: str):
        """Callback when a scheduled time hits — trigger the job."""
        async with async_session_factory() as db:
            # Check calendar blackouts
            result = await db.execute(
                select(JobDefinition).where(JobDefinition.job_name == job_name)
            )
            job = result.scalar_one_or_none()
            if not job:
                return

            should_run = await calendar_engine.should_run_today(db, job)
            if not should_run:
                logger.info(f"Skipping {job_name} — blackout date")
                return

            logger.info(f"Scheduler firing job: {job_name}")
            await execution_engine.trigger_job(db, job_name, triggered_by="schedule")

    def remove_job(self, job_name: str):
        """Remove a job from the scheduler."""
        scheduler_id = f"nexo_{job_name}"
        try:
            self._scheduler.remove_job(scheduler_id)
            self._scheduled_jobs.discard(scheduler_id)
        except Exception:
            pass


# Singleton
nexo_scheduler = NexoScheduler()
