"""
Execution Engine — the state machine that drives job lifecycle.

State machine: INACTIVE → ACTIVATED → QUE_WAIT → STARTING → RUNNING → SUCCESS/FAILURE
Side paths:    ON_HOLD, ON_ICE, TERMINATED, RESTART

This engine:
1. Picks up activated/scheduled jobs
2. Checks dependency conditions
3. Dispatches to worker pool
4. Manages state transitions
5. Handles retries
"""

import asyncio
import subprocess
import platform
import logging
import uuid
from datetime import datetime, timedelta
from typing import Optional

from sqlalchemy import select, func, update
from sqlalchemy.ext.asyncio import AsyncSession

from app.database import async_session_factory
from app.models.jobs import JobDefinition, JobRun
from app.models.enums import JobType, JobStatus, EventType
from app.core.dependency_manager import dependency_manager

logger = logging.getLogger("nexo.execution")


class ExecutionEngine:
    """Core execution engine — manages job lifecycle and worker dispatch."""

    def __init__(self):
        self._running_jobs: dict[str, asyncio.Task] = {}  # job_name -> task
        self._max_concurrent = 50
        self._shutdown = False

    async def trigger_job(
        self,
        db: AsyncSession,
        job_name: str,
        triggered_by: str = "manual",
        force: bool = False,
    ) -> Optional[JobRun]:
        """
        Trigger a job run. Creates a JobRun record and dispatches execution.
        """
        # Get job definition
        result = await db.execute(
            select(JobDefinition).where(JobDefinition.job_name == job_name)
        )
        job_def = result.scalar_one_or_none()
        if not job_def:
            raise ValueError(f"Job '{job_name}' not found")

        if not job_def.is_active:
            raise ValueError(f"Job '{job_name}' is inactive")

        # Check conditions unless forced
        if not force and job_def.condition:
            conditions_met = await dependency_manager.evaluate_conditions(
                db, job_name, job_def.condition
            )
            if not conditions_met:
                logger.info(f"Conditions not met for {job_name}, queuing")
                return await self._create_run(
                    db, job_def, JobStatus.QUE_WAIT, triggered_by
                )

        # Create run record
        run = await self._create_run(db, job_def, JobStatus.STARTING, triggered_by)
        await db.commit()

        # Dispatch execution asynchronously
        if job_def.job_type == JobType.BOX:
            asyncio.create_task(self._execute_box(job_def, run.id))
        elif job_def.job_type == JobType.FW:
            asyncio.create_task(self._execute_file_watcher(job_def, run.id))
        else:
            asyncio.create_task(self._execute_cmd(job_def, run.id))

        return run

    async def _create_run(
        self,
        db: AsyncSession,
        job_def: JobDefinition,
        initial_status: JobStatus,
        triggered_by: str,
    ) -> JobRun:
        """Create a new job run record."""
        # Get next run number
        result = await db.execute(
            select(func.coalesce(func.max(JobRun.run_number), 0))
            .where(JobRun.job_id == job_def.id)
        )
        next_run = result.scalar() + 1

        run = JobRun(
            job_id=job_def.id,
            run_number=next_run,
            status=initial_status,
            machine=job_def.machine or platform.node(),
            triggered_by=triggered_by,
            scheduled_time=datetime.utcnow(),
        )
        db.add(run)
        await db.flush()
        return run

    async def _execute_cmd(self, job_def: JobDefinition, run_id: uuid.UUID):
        """Execute a CMD job in a subprocess."""
        async with async_session_factory() as db:
            try:
                # Update status to RUNNING
                await self._update_run_status(db, run_id, JobStatus.RUNNING)

                # Execute the command
                logger.info(f"Executing CMD job: {job_def.job_name} -> {job_def.command}")

                process = await asyncio.create_subprocess_shell(
                    job_def.command,
                    stdout=asyncio.subprocess.PIPE,
                    stderr=asyncio.subprocess.PIPE,
                    cwd=None,
                )

                # Apply timeout
                timeout = job_def.max_run_alarm * 60 if job_def.max_run_alarm else 3600
                try:
                    stdout, stderr = await asyncio.wait_for(
                        process.communicate(), timeout=timeout
                    )
                except asyncio.TimeoutError:
                    process.kill()
                    await self._update_run_status(
                        db, run_id, JobStatus.TERMINATED,
                        stderr_tail="Job exceeded maximum runtime"
                    )
                    return

                exit_code = process.returncode
                stdout_text = stdout.decode("utf-8", errors="replace")[-4096:] if stdout else ""
                stderr_text = stderr.decode("utf-8", errors="replace")[-4096:] if stderr else ""

                # Determine success/failure
                max_exit = job_def.max_exit_success or 0
                status = JobStatus.SUCCESS if exit_code <= max_exit else JobStatus.FAILURE

                await self._update_run_status(
                    db, run_id, status,
                    exit_code=exit_code,
                    stdout_tail=stdout_text,
                    stderr_tail=stderr_text,
                )

                # On success, trigger downstream jobs
                if status == JobStatus.SUCCESS:
                    await self._trigger_downstream(db, job_def.job_name)
                elif status == JobStatus.FAILURE:
                    await self._handle_failure(db, job_def, run_id)

            except Exception as e:
                logger.exception(f"Error executing {job_def.job_name}")
                await self._update_run_status(
                    db, run_id, JobStatus.FAILURE,
                    stderr_tail=str(e)[:4096],
                )

    async def _execute_box(self, job_def: JobDefinition, run_id: uuid.UUID):
        """
        Execute a BOX job — trigger all children in dependency order.
        Box is RUNNING while children execute, SUCCESS when all children succeed.
        """
        async with async_session_factory() as db:
            try:
                await self._update_run_status(db, run_id, JobStatus.RUNNING)

                # Get child jobs
                result = await db.execute(
                    select(JobDefinition).where(
                        JobDefinition.box_name == job_def.job_name
                    )
                )
                children = result.scalars().all()

                if not children:
                    await self._update_run_status(db, run_id, JobStatus.SUCCESS)
                    return

                # Trigger children that have no intra-box dependencies
                for child in children:
                    if not child.condition:
                        await self.trigger_job(db, child.job_name, triggered_by="box")

                # Wait for all children to complete (poll every 5s)
                all_done = False
                box_success = True
                while not all_done:
                    await asyncio.sleep(5)
                    all_done = True
                    for child in children:
                        result = await db.execute(
                            select(JobRun)
                            .where(JobRun.job_id == child.id)
                            .order_by(JobRun.created_at.desc())
                            .limit(1)
                        )
                        latest = result.scalar_one_or_none()
                        if latest is None or latest.status in (
                            JobStatus.RUNNING, JobStatus.STARTING,
                            JobStatus.QUE_WAIT, JobStatus.ACTIVATED
                        ):
                            all_done = False
                        elif latest.status == JobStatus.FAILURE:
                            box_success = False

                status = JobStatus.SUCCESS if box_success else JobStatus.FAILURE
                await self._update_run_status(db, run_id, status)

                if status == JobStatus.SUCCESS:
                    await self._trigger_downstream(db, job_def.job_name)

            except Exception as e:
                logger.exception(f"Error executing box {job_def.job_name}")
                await self._update_run_status(db, run_id, JobStatus.FAILURE, stderr_tail=str(e))

    async def _execute_file_watcher(self, job_def: JobDefinition, run_id: uuid.UUID):
        """
        File Watcher job — polls for file existence.
        In production, this would be S3 Event → EventBridge.
        Locally, we poll the filesystem.
        """
        import os

        async with async_session_factory() as db:
            try:
                await self._update_run_status(db, run_id, JobStatus.RUNNING)

                watch_file = job_def.watch_file
                interval = job_def.watch_interval or 60
                timeout = (job_def.max_run_alarm or 60) * 60

                start = datetime.utcnow()
                found = False

                while (datetime.utcnow() - start).total_seconds() < timeout:
                    if os.path.exists(watch_file):
                        min_size = job_def.watch_file_min_size or 0
                        if os.path.getsize(watch_file) >= min_size:
                            found = True
                            break
                    await asyncio.sleep(interval)

                if found:
                    await self._update_run_status(
                        db, run_id, JobStatus.SUCCESS,
                        stdout_tail=f"File detected: {watch_file}",
                    )
                    await self._trigger_downstream(db, job_def.job_name)
                else:
                    await self._update_run_status(
                        db, run_id, JobStatus.FAILURE,
                        stderr_tail=f"File not found within timeout: {watch_file}",
                    )

            except Exception as e:
                logger.exception(f"Error in file watcher {job_def.job_name}")
                await self._update_run_status(db, run_id, JobStatus.FAILURE, stderr_tail=str(e))

    async def _update_run_status(
        self,
        db: AsyncSession,
        run_id: uuid.UUID,
        status: JobStatus,
        exit_code: Optional[int] = None,
        stdout_tail: Optional[str] = None,
        stderr_tail: Optional[str] = None,
    ):
        """Update a job run's status and publish event."""
        from app.events.event_bus import event_bus

        now = datetime.utcnow()
        values = {"status": status, "updated_at": now}

        if status == JobStatus.RUNNING:
            values["start_time"] = now
        elif status in (JobStatus.SUCCESS, JobStatus.FAILURE, JobStatus.TERMINATED):
            values["end_time"] = now

        if exit_code is not None:
            values["exit_code"] = exit_code
        if stdout_tail is not None:
            values["stdout_tail"] = stdout_tail
        if stderr_tail is not None:
            values["stderr_tail"] = stderr_tail

        # Calculate duration if ending
        if "end_time" in values:
            result = await db.execute(
                select(JobRun.start_time).where(JobRun.id == run_id)
            )
            start_time = result.scalar()
            if start_time:
                values["duration_seconds"] = (now - start_time).total_seconds()

        await db.execute(
            update(JobRun).where(JobRun.id == run_id).values(**values)
        )
        await db.commit()

        # Get job name for event
        result = await db.execute(
            select(JobDefinition.job_name)
            .join(JobRun, JobRun.job_id == JobDefinition.id)
            .where(JobRun.id == run_id)
        )
        job_name = result.scalar()

        # Publish event
        event_type_map = {
            JobStatus.RUNNING: EventType.JOB_STARTED,
            JobStatus.SUCCESS: EventType.JOB_COMPLETED,
            JobStatus.FAILURE: EventType.JOB_FAILED,
        }
        event_type = event_type_map.get(status, EventType.JOB_STATUS_CHANGED)

        await event_bus.publish(
            event_type=event_type,
            source="execution_engine",
            job_name=job_name,
            detail={
                "run_id": str(run_id),
                "status": status.value,
                "exit_code": exit_code,
            },
        )

    async def _trigger_downstream(self, db: AsyncSession, job_name: str):
        """After a job completes, check and trigger downstream dependents."""
        graph = await dependency_manager.build_graph(db)
        downstream = dependency_manager.get_downstream(graph, job_name)

        for ds_name in downstream:
            result = await db.execute(
                select(JobDefinition).where(JobDefinition.job_name == ds_name)
            )
            ds_job = result.scalar_one_or_none()
            if ds_job and ds_job.condition:
                met = await dependency_manager.evaluate_conditions(
                    db, ds_name, ds_job.condition
                )
                if met:
                    logger.info(f"Dependencies met for {ds_name}, triggering")
                    await self.trigger_job(db, ds_name, triggered_by="dependency")

    async def _handle_failure(
        self, db: AsyncSession, job_def: JobDefinition, run_id: uuid.UUID
    ):
        """Handle job failure — retry logic and alert creation."""
        from app.events.event_bus import event_bus

        result = await db.execute(
            select(JobRun).where(JobRun.id == run_id)
        )
        run = result.scalar_one()

        if run.retry_attempt < job_def.max_retries:
            logger.info(
                f"Retrying {job_def.job_name} "
                f"(attempt {run.retry_attempt + 1}/{job_def.max_retries})"
            )
            await asyncio.sleep(job_def.retry_interval)
            # Create new run for retry
            async with async_session_factory() as retry_db:
                retry_run = await self._create_run(
                    retry_db, job_def, JobStatus.STARTING, "retry"
                )
                retry_run.retry_attempt = run.retry_attempt + 1
                await retry_db.commit()

                if job_def.job_type == JobType.CMD:
                    asyncio.create_task(self._execute_cmd(job_def, retry_run.id))
        else:
            # Max retries exhausted — raise alert
            await event_bus.publish(
                event_type=EventType.ALERT_RAISED,
                source="execution_engine",
                job_name=job_def.job_name,
                detail={
                    "run_id": str(run_id),
                    "message": f"Job {job_def.job_name} failed after {job_def.max_retries} retries",
                    "exit_code": run.exit_code,
                },
            )

    async def hold_job(self, db: AsyncSession, job_name: str):
        """Put a job on hold — prevents scheduling."""
        result = await db.execute(
            select(JobRun)
            .join(JobDefinition)
            .where(JobDefinition.job_name == job_name)
            .where(JobRun.status.in_([JobStatus.QUE_WAIT, JobStatus.ACTIVATED]))
            .order_by(JobRun.created_at.desc())
            .limit(1)
        )
        run = result.scalar_one_or_none()
        if run:
            run.status = JobStatus.ON_HOLD
            await db.commit()

    async def release_hold(self, db: AsyncSession, job_name: str):
        """Release a held job."""
        result = await db.execute(
            select(JobRun)
            .join(JobDefinition)
            .where(JobDefinition.job_name == job_name)
            .where(JobRun.status == JobStatus.ON_HOLD)
            .order_by(JobRun.created_at.desc())
            .limit(1)
        )
        run = result.scalar_one_or_none()
        if run:
            run.status = JobStatus.ACTIVATED
            await db.commit()

    async def kill_job(self, db: AsyncSession, job_name: str):
        """Terminate a running job."""
        if job_name in self._running_jobs:
            self._running_jobs[job_name].cancel()
            del self._running_jobs[job_name]

        result = await db.execute(
            select(JobRun)
            .join(JobDefinition)
            .where(JobDefinition.job_name == job_name)
            .where(JobRun.status == JobStatus.RUNNING)
            .order_by(JobRun.created_at.desc())
            .limit(1)
        )
        run = result.scalar_one_or_none()
        if run:
            run.status = JobStatus.TERMINATED
            run.end_time = datetime.utcnow()
            await db.commit()


# Singleton
execution_engine = ExecutionEngine()
