"""
JIL Parser — parse and generate AutoSys-compatible JIL syntax.

Supports:
  insert_job: my_job   job_type: CMD
  command: /path/to/script.sh
  machine: server01
  condition: s(upstream_job_a) & s(upstream_job_b)
  start_times: "02:00"
  box_name: my_box
"""

import re
from typing import Optional
from app.models.enums import JobType, ConditionOperator


# ── JIL field mapping ────────────────────────────────────────────
JIL_FIELD_MAP = {
    "insert_job": "job_name",
    "update_job": "job_name",
    "job_type": "job_type",
    "command": "command",
    "machine": "machine",
    "owner": "owner",
    "permission": "permission",
    "profile": "profile",
    "std_out_file": "std_out_file",
    "std_err_file": "std_err_file",
    "box_name": "box_name",
    "start_times": "start_times",
    "start_mins": "start_mins",
    "days_of_week": "start_days",
    "run_calendar": "run_calendar",
    "exclude_calendar": "exclude_calendar",
    "timezone": "timezone",
    "condition": "condition",
    "alarm_if_fail": "alarm_if_fail",
    "alarm_if_terminated": "alarm_if_terminated",
    "max_run_alarm": "max_run_alarm",
    "min_run_alarm": "min_run_alarm",
    "max_exit_success": "max_exit_success",
    "watch_file": "watch_file",
    "watch_file_min_size": "watch_file_min_size",
    "watch_interval": "watch_interval",
    "n_retrys": "max_retries",
    "description": "description",
    "priority": "priority",
}

# Condition regex: s(job_name), f(job_name), d(job_name), n(job_name)
CONDITION_PATTERN = re.compile(r"([sfdn])\(([a-zA-Z0-9_\-\.]+)\)")


def parse_jil(jil_text: str) -> list[dict]:
    """
    Parse JIL text into a list of job definition dicts.
    Handles multiple job definitions in a single JIL block.
    """
    jobs = []
    current_job = None

    for raw_line in jil_text.strip().splitlines():
        line = raw_line.strip()
        if not line or line.startswith("/*") or line.startswith("#"):
            continue

        # New job starts with insert_job or update_job
        if line.startswith("insert_job:") or line.startswith("update_job:"):
            if current_job:
                jobs.append(current_job)
            parts = line.split(None, 1)
            key_value = parts[0]
            job_name = key_value.split(":", 1)[1].strip()
            current_job = {"job_name": job_name}

            # Check for job_type on the same line
            remaining = parts[1] if len(parts) > 1 else ""
            if "job_type:" in remaining:
                jt = remaining.split("job_type:", 1)[1].strip()
                current_job["job_type"] = jt.upper()
            continue

        if current_job is None:
            continue

        # Parse key: value pairs
        if ":" in line:
            key, _, value = line.partition(":")
            key = key.strip()
            value = value.strip().strip('"').strip("'")

            mapped_key = JIL_FIELD_MAP.get(key, key)

            # Type conversions
            if mapped_key in ("alarm_if_fail", "alarm_if_terminated", "auto_hold_on_failure"):
                value = value.lower() in ("1", "y", "yes", "true")
            elif mapped_key in ("max_run_alarm", "min_run_alarm", "max_exit_success",
                                "max_retries", "priority", "watch_file_min_size",
                                "watch_interval"):
                try:
                    value = int(value)
                except ValueError:
                    pass
            elif mapped_key == "job_type":
                value = value.upper()

            current_job[mapped_key] = value

    if current_job:
        jobs.append(current_job)

    return jobs


def generate_jil(job_data: dict) -> str:
    """Generate JIL text from a job definition dict."""
    reverse_map = {v: k for k, v in JIL_FIELD_MAP.items()}
    lines = []

    # Header
    job_name = job_data.get("job_name", "unnamed_job")
    job_type = job_data.get("job_type", "CMD")
    lines.append(f"insert_job: {job_name}   job_type: {job_type}")

    # Fields
    skip_fields = {"job_name", "job_type", "id", "created_at", "updated_at", "is_active", "tags"}
    for field, value in job_data.items():
        if field in skip_fields or value is None or value == "" or value == []:
            continue
        jil_key = reverse_map.get(field, field)
        if isinstance(value, bool):
            value = "1" if value else "0"
        lines.append(f"{jil_key}: {value}")

    lines.append("")  # trailing newline
    return "\n".join(lines)


def parse_condition(condition_str: str) -> list[dict]:
    """
    Parse a JIL condition string into structured dependency edges.
    e.g. "s(job_a) & s(job_b) | f(job_c)" →
    [
        {"job_name": "job_a", "operator": "s"},
        {"job_name": "job_b", "operator": "s"},
        {"job_name": "job_c", "operator": "f"},
    ]
    """
    if not condition_str:
        return []

    matches = CONDITION_PATTERN.findall(condition_str)
    return [
        {"job_name": name, "operator": op}
        for op, name in matches
    ]


def build_condition_string(dependencies: list[dict]) -> str:
    """Build a JIL condition string from structured dependencies."""
    if not dependencies:
        return ""
    parts = [f'{dep["operator"]}({dep["job_name"]})' for dep in dependencies]
    return " & ".join(parts)
