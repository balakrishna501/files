/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        nexo: {
          bg: '#0f1117',
          surface: '#1a1d27',
          border: '#2a2d3a',
          primary: '#3b82f6',
          success: '#22c55e',
          failure: '#ef4444',
          warning: '#f59e0b',
          inactive: '#6b7280',
          running: '#3b82f6',
          hold: '#8b5cf6',
        },
      },
      fontFamily: {
        mono: ['JetBrains Mono', 'Fira Code', 'monospace'],
      },
    },
  },
  plugins: [],
}
