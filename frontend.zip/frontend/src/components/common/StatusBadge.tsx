import { clsx } from 'clsx'
import type { JobStatus, AlertSeverity } from '../../types'

const statusColors: Record<string, string> = {
  RUNNING: 'bg-blue-500/20 text-blue-400 border-blue-500/30',
  SUCCESS: 'bg-green-500/20 text-green-400 border-green-500/30',
  FAILURE: 'bg-red-500/20 text-red-400 border-red-500/30',
  TERMINATED: 'bg-red-500/20 text-red-300 border-red-500/30',
  ON_HOLD: 'bg-purple-500/20 text-purple-400 border-purple-500/30',
  ON_ICE: 'bg-gray-500/20 text-gray-400 border-gray-500/30',
  QUE_WAIT: 'bg-amber-500/20 text-amber-400 border-amber-500/30',
  STARTING: 'bg-blue-500/20 text-blue-300 border-blue-500/30',
  ACTIVATED: 'bg-cyan-500/20 text-cyan-400 border-cyan-500/30',
  INACTIVE: 'bg-gray-500/20 text-gray-500 border-gray-500/30',
  RESTART: 'bg-orange-500/20 text-orange-400 border-orange-500/30',
  // Alert severities
  INFO: 'bg-blue-500/20 text-blue-400 border-blue-500/30',
  WARNING: 'bg-amber-500/20 text-amber-400 border-amber-500/30',
  CRITICAL: 'bg-red-500/20 text-red-400 border-red-500/30',
  // Alert statuses
  OPEN: 'bg-red-500/20 text-red-400 border-red-500/30',
  ACKNOWLEDGED: 'bg-amber-500/20 text-amber-400 border-amber-500/30',
  RESOLVED: 'bg-green-500/20 text-green-400 border-green-500/30',
  ESCALATED: 'bg-purple-500/20 text-purple-400 border-purple-500/30',
}

const statusDots: Record<string, string> = {
  RUNNING: 'bg-blue-400 animate-pulse',
  SUCCESS: 'bg-green-400',
  FAILURE: 'bg-red-400',
  ON_HOLD: 'bg-purple-400',
  QUE_WAIT: 'bg-amber-400 animate-pulse',
  STARTING: 'bg-blue-300 animate-pulse',
  CRITICAL: 'bg-red-400 animate-pulse',
  WARNING: 'bg-amber-400',
  OPEN: 'bg-red-400 animate-pulse',
}

export function StatusBadge({ status }: { status: string }) {
  return (
    <span
      className={clsx(
        'inline-flex items-center gap-1.5 px-2 py-0.5 rounded text-xs font-medium border',
        statusColors[status] || 'bg-gray-500/20 text-gray-400 border-gray-500/30'
      )}
    >
      <span
        className={clsx(
          'w-1.5 h-1.5 rounded-full',
          statusDots[status] || 'bg-gray-400'
        )}
      />
      {status}
    </span>
  )
}
