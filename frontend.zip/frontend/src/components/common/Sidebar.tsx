import { clsx } from 'clsx'
import {
  LayoutDashboard,
  Monitor,
  FilePlus,
  GitBranch,
  CalendarDays,
  Bell,
  MessageSquare,
} from 'lucide-react'
import { useStore } from '../../stores/useStore'

const navItems = [
  { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
  { id: 'monitor', label: 'Job Monitor', icon: Monitor },
  { id: 'define', label: 'Define Job', icon: FilePlus },
  { id: 'dependencies', label: 'Dependencies', icon: GitBranch },
  { id: 'calendar', label: 'Calendar', icon: CalendarDays },
  { id: 'alerts', label: 'Alerts', icon: Bell },
  { id: 'chat', label: 'AI Chat', icon: MessageSquare },
]

export function Sidebar() {
  const { activePage, setActivePage } = useStore()

  return (
    <aside className="w-56 bg-nexo-surface border-r border-nexo-border flex flex-col h-screen sticky top-0">
      {/* Logo */}
      <div className="p-4 border-b border-nexo-border">
        <h1 className="text-xl font-bold tracking-wider text-nexo-primary">
          NEXO
        </h1>
        <p className="text-[10px] text-gray-500 mt-0.5">
          Workload Automation
        </p>
      </div>

      {/* Navigation */}
      <nav className="flex-1 py-2">
        {navItems.map((item) => (
          <button
            key={item.id}
            onClick={() => setActivePage(item.id)}
            className={clsx(
              'w-full flex items-center gap-3 px-4 py-2.5 text-sm transition-colors',
              activePage === item.id
                ? 'bg-nexo-primary/10 text-nexo-primary border-r-2 border-nexo-primary'
                : 'text-gray-400 hover:text-gray-200 hover:bg-nexo-border/30'
            )}
          >
            <item.icon size={16} />
            {item.label}
          </button>
        ))}
      </nav>

      {/* Footer */}
      <div className="p-3 border-t border-nexo-border text-[10px] text-gray-600">
        NEXO v1.0.0
      </div>
    </aside>
  )
}
