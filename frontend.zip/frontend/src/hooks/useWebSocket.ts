import { useEffect, useRef } from 'react'
import { useStore } from '../stores/useStore'

export function useWebSocket() {
  const ws = useRef<WebSocket | null>(null)
  const addEvent = useStore((s) => s.addRealtimeEvent)

  useEffect(() => {
    const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:'
    const url = `${protocol}//${window.location.host}/ws`

    function connect() {
      ws.current = new WebSocket(url)

      ws.current.onmessage = (event) => {
        try {
          const data = JSON.parse(event.data)
          addEvent(data.data || data)
        } catch {
          // ignore parse errors
        }
      }

      ws.current.onclose = () => {
        setTimeout(connect, 3000) // auto-reconnect
      }

      ws.current.onerror = () => {
        ws.current?.close()
      }
    }

    connect()

    return () => {
      ws.current?.close()
    }
  }, [addEvent])
}
