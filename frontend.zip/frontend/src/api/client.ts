const BASE = '/api'

async function request<T>(path: string, options?: RequestInit): Promise<T> {
  const res = await fetch(`${BASE}${path}`, {
    headers: { 'Content-Type': 'application/json' },
    ...options,
  })
  if (!res.ok) {
    const err = await res.json().catch(() => ({ detail: res.statusText }))
    throw new Error(err.detail || res.statusText)
  }
  if (res.status === 204) return undefined as T
  return res.json()
}

// ── Jobs ─────────────────────────────────────────────────────────

import type {
  JobDefinition, JobRun, DashboardStats,
  Alert, NexoEvent, GraphData, ChatResponse,
} from '../types'

export const api = {
  // Jobs
  listJobs: (params?: { search?: string; job_type?: string }) => {
    const qs = new URLSearchParams()
    if (params?.search) qs.set('search', params.search)
    if (params?.job_type) qs.set('job_type', params.job_type)
    return request<JobDefinition[]>(`/jobs?${qs}`)
  },
  getJob: (name: string) => request<JobDefinition>(`/jobs/${name}`),
  createJob: (data: Partial<JobDefinition>) =>
    request<JobDefinition>('/jobs', { method: 'POST', body: JSON.stringify(data) }),
  updateJob: (name: string, data: Partial<JobDefinition>) =>
    request<JobDefinition>(`/jobs/${name}`, { method: 'PUT', body: JSON.stringify(data) }),
  deleteJob: (name: string) =>
    request<void>(`/jobs/${name}`, { method: 'DELETE' }),
  triggerJob: (name: string, force = false) =>
    request<JobRun>(`/jobs/${name}/trigger?force=${force}`, { method: 'POST' }),
  holdJob: (name: string) =>
    request<any>(`/jobs/${name}/hold`, { method: 'POST' }),
  releaseJob: (name: string) =>
    request<any>(`/jobs/${name}/release`, { method: 'POST' }),
  killJob: (name: string) =>
    request<any>(`/jobs/${name}/kill`, { method: 'POST' }),
  getJobRuns: (name: string, limit = 20) =>
    request<JobRun[]>(`/jobs/${name}/runs?limit=${limit}`),
  getJobJil: (name: string) =>
    request<{ jil_text: string }>(`/jobs/${name}/jil`),
  importJil: (jil_text: string) =>
    request<{ imported: number; job_names: string[] }>('/jobs/import/jil', {
      method: 'POST', body: JSON.stringify({ jil_text }),
    }),

  // Dashboard
  getStats: () => request<DashboardStats>('/jobs/stats'),

  // Dependencies
  getGraph: () => request<GraphData>('/dependencies/graph'),
  getCriticalPath: (name: string) =>
    request<{ critical_path: string[] }>(`/dependencies/${name}/critical-path`),

  // Events
  getEvents: (hours = 24, limit = 50) =>
    request<NexoEvent[]>(`/events?hours=${hours}&limit=${limit}`),

  // Alerts
  getAlerts: (status?: string) => {
    const qs = status ? `?status=${status}` : ''
    return request<Alert[]>(`/alerts${qs}`)
  },
  alertAction: (id: string, action: string, user?: string) =>
    request<Alert>(`/alerts/${id}/action`, {
      method: 'POST',
      body: JSON.stringify({ action, user }),
    }),

  // Schedule
  getTodaySchedule: () => request<any[]>('/schedule/today'),
  getGantt: (date?: string) => {
    const qs = date ? `?start_date=${date}&end_date=${date}` : ''
    return request<any[]>(`/schedule/gantt${qs}`)
  },

  // AI
  chat: (messages: { role: string; content: string }[]) =>
    request<ChatResponse>('/ai/chat', {
      method: 'POST',
      body: JSON.stringify({ messages }),
    }),
  generateJob: (prompt: string) =>
    request<any>('/ai/generate-job', {
      method: 'POST',
      body: JSON.stringify({ prompt }),
    }),
  analyzeFailure: (job_name: string) =>
    request<any>('/ai/analyze', {
      method: 'POST',
      body: JSON.stringify({ job_name }),
    }),
}
