import { Sidebar } from './components/common/Sidebar'
import { Dashboard } from './pages/Dashboard'
import { JobMonitor } from './pages/JobMonitor'
import { DefineJob } from './pages/DefineJob'
import { Dependencies } from './pages/Dependencies'
import { CalendarView } from './pages/CalendarView'
import { Alerts } from './pages/Alerts'
import { AIChat } from './pages/AIChat'
import { useStore } from './stores/useStore'
import { useWebSocket } from './hooks/useWebSocket'

const pages: Record<string, React.FC> = {
  dashboard: Dashboard,
  monitor: JobMonitor,
  define: DefineJob,
  dependencies: Dependencies,
  calendar: CalendarView,
  alerts: Alerts,
  chat: AIChat,
}

export default function App() {
  const activePage = useStore((s) => s.activePage)
  useWebSocket()

  const PageComponent = pages[activePage] || Dashboard

  return (
    <div className="flex h-screen overflow-hidden">
      <Sidebar />
      <main className="flex-1 overflow-auto">
        <PageComponent />
      </main>
    </div>
  )
}
