import { useState } from 'react'
import { useQuery } from '@tanstack/react-query'
import { ChevronLeft, ChevronRight } from 'lucide-react'
import { format, addDays, subDays } from 'date-fns'
import { api } from '../api/client'
import { StatusBadge } from '../components/common/StatusBadge'

export function CalendarView() {
  const [selectedDate, setSelectedDate] = useState(new Date())
  const dateStr = format(selectedDate, 'yyyy-MM-dd')

  const { data: ganttItems } = useQuery({
    queryKey: ['gantt', dateStr],
    queryFn: () => api.getGantt(dateStr),
  })

  const { data: schedule } = useQuery({
    queryKey: ['schedule', dateStr],
    queryFn: () => api.getTodaySchedule(),
  })

  // Build 24-hour timeline
  const hours = Array.from({ length: 24 }, (_, i) => i)

  return (
    <div className="p-6 space-y-4">
      {/* Date selector */}
      <div className="flex items-center gap-4">
        <button
          onClick={() => setSelectedDate((d) => subDays(d, 1))}
          className="p-1.5 rounded bg-nexo-surface border border-nexo-border hover:bg-nexo-border text-gray-400"
        >
          <ChevronLeft size={14} />
        </button>
        <h2 className="text-sm font-medium text-gray-200">
          {format(selectedDate, 'EEEE, MMMM d, yyyy')}
        </h2>
        <button
          onClick={() => setSelectedDate((d) => addDays(d, 1))}
          className="p-1.5 rounded bg-nexo-surface border border-nexo-border hover:bg-nexo-border text-gray-400"
        >
          <ChevronRight size={14} />
        </button>
      </div>

      {/* Gantt chart */}
      <div className="bg-nexo-surface border border-nexo-border rounded-lg overflow-hidden">
        <div className="p-3 border-b border-nexo-border">
          <h3 className="text-xs font-medium text-gray-400">Batch Window Timeline</h3>
        </div>

        {/* Hour headers */}
        <div className="flex border-b border-nexo-border">
          <div className="w-48 shrink-0 px-3 py-1 text-[10px] text-gray-500 border-r border-nexo-border">
            Job
          </div>
          <div className="flex-1 flex">
            {hours.map((h) => (
              <div
                key={h}
                className="flex-1 text-center text-[10px] text-gray-600 py-1 border-r border-nexo-border/30"
              >
                {String(h).padStart(2, '0')}
              </div>
            ))}
          </div>
        </div>

        {/* Job rows */}
        <div className="divide-y divide-nexo-border/50">
          {(ganttItems ?? []).map((item) => (
            <GanttRow key={item.id} item={item} />
          ))}
          {(schedule ?? []).map((item: any, i: number) => (
            <div key={i} className="flex items-center">
              <div className="w-48 shrink-0 px-3 py-2 text-xs font-mono text-gray-300 border-r border-nexo-border truncate">
                {item.job_name}
              </div>
              <div className="flex-1 relative h-8">
                {item.fire_time && (
                  <div
                    className="absolute top-1 h-6 bg-nexo-primary/30 border border-nexo-primary/50 rounded text-[10px] flex items-center px-1 text-blue-300"
                    style={{
                      left: `${(new Date(item.fire_time).getHours() / 24) * 100}%`,
                      width: '4%',
                      minWidth: '40px',
                    }}
                  >
                    {format(new Date(item.fire_time), 'HH:mm')}
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>

        {(!ganttItems?.length && !schedule?.length) && (
          <div className="p-8 text-center text-gray-500 text-sm">
            No scheduled jobs for this date.
          </div>
        )}
      </div>
    </div>
  )
}

function GanttRow({ item }: { item: any }) {
  const startHour = item.start_time ? new Date(item.start_time).getHours() + new Date(item.start_time).getMinutes() / 60 : 0
  const duration = item.duration_seconds ? item.duration_seconds / 3600 : 0.5

  const statusColor: Record<string, string> = {
    SUCCESS: 'bg-green-500/30 border-green-500/50',
    FAILURE: 'bg-red-500/30 border-red-500/50',
    RUNNING: 'bg-blue-500/30 border-blue-500/50 animate-pulse',
    QUE_WAIT: 'bg-amber-500/20 border-amber-500/30 border-dashed',
  }

  return (
    <div className="flex items-center">
      <div className="w-48 shrink-0 px-3 py-2 text-xs font-mono text-gray-300 border-r border-nexo-border truncate">
        {item.job_name}
      </div>
      <div className="flex-1 relative h-8">
        <div
          className={`absolute top-1 h-6 rounded border text-[10px] flex items-center px-1 ${statusColor[item.status] || 'bg-gray-500/20 border-gray-500/30'}`}
          style={{
            left: `${(startHour / 24) * 100}%`,
            width: `${Math.max((duration / 24) * 100, 2)}%`,
            minWidth: '30px',
          }}
        >
          <StatusBadge status={item.status} />
        </div>
      </div>
    </div>
  )
}
