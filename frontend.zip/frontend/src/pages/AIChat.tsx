import { useState, useRef, useEffect } from 'react'
import { Send, Bot, User, Sparkles } from 'lucide-react'
import { api } from '../api/client'
import { useStore } from '../stores/useStore'

export function AIChat() {
  const { chatMessages, addChatMessage, clearChat } = useStore()
  const [input, setInput] = useState('')
  const [loading, setLoading] = useState(false)
  const bottomRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' })
  }, [chatMessages])

  const sendMessage = async () => {
    if (!input.trim() || loading) return

    const userMsg = { role: 'user' as const, content: input.trim() }
    addChatMessage(userMsg)
    setInput('')
    setLoading(true)

    try {
      const allMessages = [...chatMessages, userMsg].map((m) => ({
        role: m.role,
        content: m.content,
      }))

      const response = await api.chat(allMessages)
      addChatMessage({ role: 'assistant', content: response.response })

      if (response.actions_taken.length > 0) {
        addChatMessage({
          role: 'assistant',
          content: `_Actions: ${response.actions_taken.join(', ')}_`,
        })
      }
    } catch (err) {
      addChatMessage({
        role: 'assistant',
        content: `Error: ${(err as Error).message}`,
      })
    } finally {
      setLoading(false)
    }
  }

  const quickActions = [
    'Show me all failed jobs in the last 24 hours',
    'What jobs are currently running?',
    'Create a job that runs cleanup every night at 3am',
    'Analyze why BOX_PAYROLL might be failing',
    'Optimize the schedule for CMD_DAILY_REPORT',
  ]

  return (
    <div className="p-6 h-[calc(100vh-2rem)] flex flex-col">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2">
          <Sparkles size={16} className="text-amber-400" />
          <h2 className="text-lg font-semibold">NEXO AI Assistant</h2>
        </div>
        <button
          onClick={clearChat}
          className="text-xs text-gray-500 hover:text-gray-300 px-2 py-1 rounded border border-nexo-border"
        >
          Clear Chat
        </button>
      </div>

      {/* Messages */}
      <div className="flex-1 bg-nexo-surface border border-nexo-border rounded-lg overflow-auto p-4 space-y-4">
        {chatMessages.length === 0 && (
          <div className="space-y-4">
            <div className="text-center py-8">
              <Bot size={32} className="mx-auto text-nexo-primary opacity-50 mb-3" />
              <p className="text-sm text-gray-400">
                Ask me anything about your jobs, schedules, or failures.
              </p>
              <p className="text-xs text-gray-600 mt-1">
                I can also create jobs from natural language descriptions.
              </p>
            </div>
            <div className="space-y-2">
              <p className="text-xs text-gray-500 uppercase tracking-wide">Quick actions</p>
              {quickActions.map((q, i) => (
                <button
                  key={i}
                  onClick={() => { setInput(q); }}
                  className="block w-full text-left px-3 py-2 text-xs text-gray-400 bg-nexo-bg rounded border border-nexo-border hover:border-nexo-primary hover:text-gray-200 transition-colors"
                >
                  {q}
                </button>
              ))}
            </div>
          </div>
        )}

        {chatMessages.map((msg, i) => (
          <div
            key={i}
            className={`flex gap-3 ${msg.role === 'user' ? 'justify-end' : ''}`}
          >
            {msg.role === 'assistant' && (
              <div className="w-6 h-6 rounded bg-nexo-primary/20 flex items-center justify-center shrink-0 mt-0.5">
                <Bot size={12} className="text-nexo-primary" />
              </div>
            )}
            <div
              className={`max-w-[80%] rounded-lg px-3 py-2 text-sm ${
                msg.role === 'user'
                  ? 'bg-nexo-primary/20 text-gray-200'
                  : 'bg-nexo-bg text-gray-300 border border-nexo-border'
              }`}
            >
              <pre className="whitespace-pre-wrap font-mono text-xs">{msg.content}</pre>
            </div>
            {msg.role === 'user' && (
              <div className="w-6 h-6 rounded bg-gray-500/20 flex items-center justify-center shrink-0 mt-0.5">
                <User size={12} className="text-gray-400" />
              </div>
            )}
          </div>
        ))}

        {loading && (
          <div className="flex gap-3">
            <div className="w-6 h-6 rounded bg-nexo-primary/20 flex items-center justify-center">
              <Bot size={12} className="text-nexo-primary animate-pulse" />
            </div>
            <div className="bg-nexo-bg border border-nexo-border rounded-lg px-3 py-2 text-sm text-gray-500">
              Thinking...
            </div>
          </div>
        )}

        <div ref={bottomRef} />
      </div>

      {/* Input */}
      <div className="mt-3 flex gap-2">
        <input
          type="text"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={(e) => e.key === 'Enter' && sendMessage()}
          placeholder="Ask NEXO AI..."
          className="flex-1 bg-nexo-surface border border-nexo-border rounded-lg px-4 py-2.5 text-sm text-gray-200 placeholder-gray-600 focus:border-nexo-primary focus:outline-none"
        />
        <button
          onClick={sendMessage}
          disabled={!input.trim() || loading}
          className="px-4 py-2.5 bg-nexo-primary text-white rounded-lg hover:bg-blue-600 disabled:opacity-40 transition-colors"
        >
          <Send size={16} />
        </button>
      </div>
    </div>
  )
}
