import { useState } from 'react'
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import { Shield, CheckCircle, ArrowUpRight, Wrench } from 'lucide-react'
import { api } from '../api/client'
import { StatusBadge } from '../components/common/StatusBadge'
import type { Alert } from '../types'

export function Alerts() {
  const [statusFilter, setStatusFilter] = useState<string>('')
  const queryClient = useQueryClient()

  const { data: alerts } = useQuery({
    queryKey: ['alerts', statusFilter],
    queryFn: () => api.getAlerts(statusFilter || undefined),
  })

  const actionMut = useMutation({
    mutationFn: ({ id, action }: { id: string; action: string }) =>
      api.alertAction(id, action, 'operator'),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['alerts'] }),
  })

  return (
    <div className="p-6 space-y-4">
      <div className="flex items-center justify-between">
        <h2 className="text-lg font-semibold">Alerts</h2>
        <div className="flex gap-2">
          {['', 'OPEN', 'ACKNOWLEDGED', 'RESOLVED'].map((s) => (
            <button
              key={s}
              onClick={() => setStatusFilter(s)}
              className={`px-3 py-1 rounded text-xs ${
                statusFilter === s
                  ? 'bg-nexo-primary text-white'
                  : 'bg-nexo-surface border border-nexo-border text-gray-400 hover:text-gray-200'
              }`}
            >
              {s || 'All'}
            </button>
          ))}
        </div>
      </div>

      <div className="space-y-3">
        {(alerts ?? []).map((alert) => (
          <AlertCard
            key={alert.id}
            alert={alert}
            onAction={(action) => actionMut.mutate({ id: alert.id, action })}
          />
        ))}
        {(!alerts || alerts.length === 0) && (
          <div className="bg-nexo-surface border border-nexo-border rounded-lg p-8 text-center text-gray-500 text-sm">
            No alerts. All systems operational.
          </div>
        )}
      </div>
    </div>
  )
}

function AlertCard({
  alert,
  onAction,
}: {
  alert: Alert
  onAction: (action: string) => void
}) {
  const [expanded, setExpanded] = useState(false)

  return (
    <div className="bg-nexo-surface border border-nexo-border rounded-lg overflow-hidden">
      <div
        className="p-4 flex items-start gap-3 cursor-pointer hover:bg-nexo-border/10"
        onClick={() => setExpanded(!expanded)}
      >
        <div className="mt-0.5">
          <StatusBadge status={alert.severity} />
        </div>
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2">
            <span className="text-sm font-medium text-gray-200">{alert.title}</span>
            <StatusBadge status={alert.status} />
          </div>
          {alert.job_name && (
            <span className="text-xs text-gray-500 font-mono">{alert.job_name}</span>
          )}
          <p className="text-xs text-gray-500 mt-1">
            {new Date(alert.created_at).toLocaleString()}
          </p>
        </div>

        {/* Action buttons */}
        {alert.status === 'OPEN' && (
          <div className="flex gap-1.5">
            <button
              onClick={(e) => { e.stopPropagation(); onAction('acknowledge') }}
              className="p-1.5 rounded bg-amber-500/10 text-amber-400 hover:bg-amber-500/20"
              title="Acknowledge"
            >
              <Shield size={12} />
            </button>
            <button
              onClick={(e) => { e.stopPropagation(); onAction('remediate') }}
              className="p-1.5 rounded bg-blue-500/10 text-blue-400 hover:bg-blue-500/20"
              title="Remediate"
            >
              <Wrench size={12} />
            </button>
            <button
              onClick={(e) => { e.stopPropagation(); onAction('escalate') }}
              className="p-1.5 rounded bg-purple-500/10 text-purple-400 hover:bg-purple-500/20"
              title="Escalate"
            >
              <ArrowUpRight size={12} />
            </button>
            <button
              onClick={(e) => { e.stopPropagation(); onAction('resolve') }}
              className="p-1.5 rounded bg-green-500/10 text-green-400 hover:bg-green-500/20"
              title="Resolve"
            >
              <CheckCircle size={12} />
            </button>
          </div>
        )}
      </div>

      {expanded && (
        <div className="px-4 pb-4 space-y-2 border-t border-nexo-border pt-3">
          {alert.description && (
            <div>
              <span className="text-[10px] text-gray-500 uppercase">Description</span>
              <p className="text-xs text-gray-300">{alert.description}</p>
            </div>
          )}
          {alert.ai_analysis && (
            <div>
              <span className="text-[10px] text-gray-500 uppercase">AI Analysis</span>
              <p className="text-xs text-gray-300">{alert.ai_analysis}</p>
            </div>
          )}
          {alert.remediation_action && (
            <div>
              <span className="text-[10px] text-gray-500 uppercase">Remediation Action</span>
              <p className="text-xs text-green-400">{alert.remediation_action}</p>
            </div>
          )}
        </div>
      )}
    </div>
  )
}
