import { useState } from 'react'
import { useMutation, useQueryClient } from '@tanstack/react-query'
import { Sparkles, Save, FileText } from 'lucide-react'
import { api } from '../api/client'
import type { JobType } from '../types'

const emptyJob = {
  job_name: '',
  job_type: 'CMD' as JobType,
  command: '',
  machine: 'localhost',
  owner: '',
  box_name: '',
  start_times: '',
  cron_expression: '',
  condition: '',
  description: '',
  max_retries: 0,
  tags: [] as string[],
  priority: 0,
  is_active: true,
  timezone: 'UTC',
}

export function DefineJob() {
  const [form, setForm] = useState(emptyJob)
  const [jilPreview, setJilPreview] = useState('')
  const [nlPrompt, setNlPrompt] = useState('')
  const [tagInput, setTagInput] = useState('')
  const queryClient = useQueryClient()

  const createMut = useMutation({
    mutationFn: (data: typeof form) => api.createJob({
      ...data,
      tags: data.tags,
    }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['jobs'] })
      setForm(emptyJob)
      setJilPreview('')
    },
  })

  const aiGenMut = useMutation({
    mutationFn: (prompt: string) => api.generateJob(prompt),
    onSuccess: (data) => {
      if (data.job_definitions?.[0]) {
        const jd = data.job_definitions[0]
        setForm((f) => ({
          ...f,
          ...jd,
          tags: jd.tags || [],
        }))
      }
      setJilPreview(data.generated_jil || '')
    },
  })

  const updateField = (field: string, value: any) => {
    setForm((f) => ({ ...f, [field]: value }))
  }

  const addTag = () => {
    if (tagInput.trim() && !form.tags.includes(tagInput.trim())) {
      setForm((f) => ({ ...f, tags: [...f.tags, tagInput.trim()] }))
      setTagInput('')
    }
  }

  const removeTag = (tag: string) => {
    setForm((f) => ({ ...f, tags: f.tags.filter((t) => t !== tag) }))
  }

  return (
    <div className="p-6 flex gap-6 h-[calc(100vh-2rem)]">
      {/* Form */}
      <div className="flex-1 bg-nexo-surface border border-nexo-border rounded-lg overflow-auto">
        <div className="p-4 border-b border-nexo-border flex items-center justify-between">
          <h3 className="text-sm font-medium">Define Job</h3>
          <button
            onClick={() => createMut.mutate(form)}
            disabled={!form.job_name || createMut.isPending}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-nexo-primary text-white rounded text-xs hover:bg-blue-600 disabled:opacity-40"
          >
            <Save size={12} />
            {createMut.isPending ? 'Saving...' : 'Save Job'}
          </button>
        </div>

        {/* AI Generate */}
        <div className="p-4 border-b border-nexo-border bg-nexo-bg/50">
          <label className="text-xs text-gray-500 flex items-center gap-1 mb-2">
            <Sparkles size={12} className="text-amber-400" /> AI Job Generator
          </label>
          <div className="flex gap-2">
            <input
              type="text"
              placeholder="e.g. Run payroll every weekday at 2am after GL close succeeds"
              value={nlPrompt}
              onChange={(e) => setNlPrompt(e.target.value)}
              className="flex-1 bg-nexo-bg border border-nexo-border rounded px-3 py-1.5 text-sm text-gray-200 placeholder-gray-600 focus:border-amber-500 focus:outline-none"
            />
            <button
              onClick={() => aiGenMut.mutate(nlPrompt)}
              disabled={!nlPrompt || aiGenMut.isPending}
              className="px-3 py-1.5 bg-amber-500/20 text-amber-400 border border-amber-500/30 rounded text-xs hover:bg-amber-500/30 disabled:opacity-40"
            >
              {aiGenMut.isPending ? 'Generating...' : 'Generate'}
            </button>
          </div>
        </div>

        <div className="p-4 grid grid-cols-2 gap-4 text-xs">
          <Field label="Job Name *" value={form.job_name} onChange={(v) => updateField('job_name', v)} placeholder="MY_JOB_NAME" />
          <div>
            <label className="text-gray-500 block mb-1">Job Type *</label>
            <select
              value={form.job_type}
              onChange={(e) => updateField('job_type', e.target.value)}
              className="w-full bg-nexo-bg border border-nexo-border rounded px-2 py-1.5 text-gray-200"
            >
              <option value="CMD">CMD</option>
              <option value="BOX">BOX</option>
              <option value="FW">FW</option>
            </select>
          </div>
          <Field label="Command" value={form.command} onChange={(v) => updateField('command', v)} placeholder="/path/to/script.sh" fullWidth />
          <Field label="Machine" value={form.machine} onChange={(v) => updateField('machine', v)} />
          <Field label="Owner" value={form.owner} onChange={(v) => updateField('owner', v)} />
          <Field label="Box Name" value={form.box_name} onChange={(v) => updateField('box_name', v)} placeholder="Parent box job" />
          <Field label="Start Times" value={form.start_times} onChange={(v) => updateField('start_times', v)} placeholder="02:00, 14:00" />
          <Field label="Cron Expression" value={form.cron_expression} onChange={(v) => updateField('cron_expression', v)} placeholder="0 2 * * 1-5" />
          <Field label="Condition" value={form.condition} onChange={(v) => updateField('condition', v)} placeholder="s(job_a) & s(job_b)" fullWidth />
          <Field label="Description" value={form.description} onChange={(v) => updateField('description', v)} fullWidth />
          <Field label="Max Retries" value={String(form.max_retries)} onChange={(v) => updateField('max_retries', parseInt(v) || 0)} type="number" />
          <Field label="Priority" value={String(form.priority)} onChange={(v) => updateField('priority', parseInt(v) || 0)} type="number" />

          {/* Tags */}
          <div className="col-span-2">
            <label className="text-gray-500 block mb-1">Tags</label>
            <div className="flex gap-2 items-center flex-wrap">
              {form.tags.map((t) => (
                <span key={t} className="inline-flex items-center gap-1 bg-nexo-border rounded px-2 py-0.5 text-gray-300">
                  {t}
                  <button onClick={() => removeTag(t)} className="text-gray-500 hover:text-red-400">&times;</button>
                </span>
              ))}
              <input
                value={tagInput}
                onChange={(e) => setTagInput(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && (e.preventDefault(), addTag())}
                placeholder="Add tag..."
                className="bg-nexo-bg border border-nexo-border rounded px-2 py-1 text-gray-200 w-24"
              />
            </div>
          </div>
        </div>

        {createMut.isError && (
          <div className="mx-4 mb-4 p-2 bg-red-500/10 border border-red-500/30 rounded text-xs text-red-400">
            {(createMut.error as Error).message}
          </div>
        )}
        {createMut.isSuccess && (
          <div className="mx-4 mb-4 p-2 bg-green-500/10 border border-green-500/30 rounded text-xs text-green-400">
            Job created successfully!
          </div>
        )}
      </div>

      {/* JIL Preview */}
      <div className="w-96 bg-nexo-surface border border-nexo-border rounded-lg flex flex-col">
        <div className="p-3 border-b border-nexo-border flex items-center gap-2">
          <FileText size={14} className="text-gray-400" />
          <span className="text-xs font-medium text-gray-300">JIL Preview</span>
        </div>
        <pre className="flex-1 p-4 text-xs text-green-400 font-mono overflow-auto whitespace-pre-wrap">
          {jilPreview || generateJilPreview(form)}
        </pre>
      </div>
    </div>
  )
}

function Field({
  label, value, onChange, placeholder, type, fullWidth,
}: {
  label: string; value: string; onChange: (v: string) => void
  placeholder?: string; type?: string; fullWidth?: boolean
}) {
  return (
    <div className={fullWidth ? 'col-span-2' : ''}>
      <label className="text-gray-500 block mb-1">{label}</label>
      <input
        type={type || 'text'}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder={placeholder}
        className="w-full bg-nexo-bg border border-nexo-border rounded px-2 py-1.5 text-gray-200 placeholder-gray-600 focus:border-nexo-primary focus:outline-none"
      />
    </div>
  )
}

function generateJilPreview(form: typeof emptyJob): string {
  if (!form.job_name) return '/* Enter a job name to see JIL preview */'

  const lines = [`insert_job: ${form.job_name}   job_type: ${form.job_type}`]
  if (form.command) lines.push(`command: ${form.command}`)
  if (form.machine) lines.push(`machine: ${form.machine}`)
  if (form.owner) lines.push(`owner: ${form.owner}`)
  if (form.box_name) lines.push(`box_name: ${form.box_name}`)
  if (form.start_times) lines.push(`start_times: "${form.start_times}"`)
  if (form.cron_expression) lines.push(`/* cron: ${form.cron_expression} */`)
  if (form.condition) lines.push(`condition: ${form.condition}`)
  if (form.description) lines.push(`description: "${form.description}"`)
  if (form.max_retries) lines.push(`n_retrys: ${form.max_retries}`)
  if (form.priority) lines.push(`priority: ${form.priority}`)
  return lines.join('\n')
}
