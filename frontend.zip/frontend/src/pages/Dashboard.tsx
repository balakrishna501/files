import { useQuery } from '@tanstack/react-query'
import { Activity, CheckCircle, XCircle, Pause, AlertTriangle, Server } from 'lucide-react'
import { api } from '../api/client'
import { StatusBadge } from '../components/common/StatusBadge'
import { useStore } from '../stores/useStore'

function StatCard({
  label, value, icon: Icon, color,
}: {
  label: string; value: number; icon: any; color: string
}) {
  return (
    <div className="bg-nexo-surface border border-nexo-border rounded-lg p-4">
      <div className="flex items-center justify-between">
        <div>
          <p className="text-xs text-gray-500 uppercase tracking-wide">{label}</p>
          <p className={`text-2xl font-bold mt-1 ${color}`}>{value}</p>
        </div>
        <Icon className={`${color} opacity-40`} size={28} />
      </div>
    </div>
  )
}

export function Dashboard() {
  const { data: stats } = useQuery({
    queryKey: ['stats'],
    queryFn: api.getStats,
  })

  const { data: events } = useQuery({
    queryKey: ['events'],
    queryFn: () => api.getEvents(24, 20),
  })

  const setActivePage = useStore((s) => s.setActivePage)
  const setSelectedJob = useStore((s) => s.setSelectedJob)

  return (
    <div className="p-6 space-y-6">
      <h2 className="text-lg font-semibold">Dashboard</h2>

      {/* Stat Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 xl:grid-cols-6 gap-4">
        <StatCard label="Total Jobs" value={stats?.total_jobs ?? 0} icon={Server} color="text-gray-100" />
        <StatCard label="Running" value={stats?.running_now ?? 0} icon={Activity} color="text-blue-400" />
        <StatCard label="Success (24h)" value={stats?.success_24h ?? 0} icon={CheckCircle} color="text-green-400" />
        <StatCard label="Failed (24h)" value={stats?.failed_24h ?? 0} icon={XCircle} color="text-red-400" />
        <StatCard label="On Hold" value={stats?.on_hold ?? 0} icon={Pause} color="text-purple-400" />
        <StatCard label="SLA At Risk" value={stats?.sla_at_risk ?? 0} icon={AlertTriangle} color="text-amber-400" />
      </div>

      {/* Recent Activity */}
      <div className="bg-nexo-surface border border-nexo-border rounded-lg">
        <div className="px-4 py-3 border-b border-nexo-border">
          <h3 className="text-sm font-medium text-gray-300">Recent Activity</h3>
        </div>
        <div className="divide-y divide-nexo-border">
          {(events ?? []).map((event) => (
            <div
              key={event.id}
              className="px-4 py-2.5 flex items-center gap-4 text-xs hover:bg-nexo-border/20 cursor-pointer"
              onClick={() => {
                if (event.job_name) {
                  setSelectedJob(event.job_name)
                  setActivePage('monitor')
                }
              }}
            >
              <span className="text-gray-500 w-36 shrink-0">
                {new Date(event.created_at).toLocaleTimeString()}
              </span>
              <StatusBadge status={event.event_type.replace('JOB_', '')} />
              <span className="font-mono text-gray-300">
                {event.job_name || event.source}
              </span>
              <span className="text-gray-500 truncate ml-auto">
                {event.source}
              </span>
            </div>
          ))}
          {(!events || events.length === 0) && (
            <div className="px-4 py-8 text-center text-gray-500 text-sm">
              No recent activity. Trigger a job to see events here.
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
