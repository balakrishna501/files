import { useMemo, useCallback } from 'react'
import { useQuery } from '@tanstack/react-query'
import {
  ReactFlow,
  Controls,
  Background,
  useNodesState,
  useEdgesState,
  MarkerType,
  BackgroundVariant,
  type Node,
  type Edge,
} from '@xyflow/react'
import '@xyflow/react/dist/style.css'
import { api } from '../api/client'
import { useStore } from '../stores/useStore'

// Custom node component for jobs
function JobNode({ data }: { data: { label: string } }) {
  return (
    <div className="bg-nexo-surface border border-nexo-border rounded px-3 py-2 text-xs font-mono text-gray-200 shadow-lg hover:border-nexo-primary transition-colors min-w-[140px] text-center">
      {data.label}
    </div>
  )
}

const nodeTypes = { jobNode: JobNode }

export function Dependencies() {
  const { data: graphData, isLoading } = useQuery({
    queryKey: ['graph'],
    queryFn: api.getGraph,
    refetchInterval: 10000,
  })

  const setSelectedJob = useStore((s) => s.setSelectedJob)
  const setActivePage = useStore((s) => s.setActivePage)

  // Layout: simple layered left-to-right using topological levels
  const { layoutNodes, layoutEdges } = useMemo(() => {
    if (!graphData?.nodes?.length) return { layoutNodes: [], layoutEdges: [] }

    // Build adjacency for level assignment
    const incoming: Record<string, Set<string>> = {}
    const outgoing: Record<string, Set<string>> = {}
    graphData.nodes.forEach((n) => {
      incoming[n.id] = new Set()
      outgoing[n.id] = new Set()
    })
    graphData.edges.forEach((e) => {
      incoming[e.target]?.add(e.source)
      outgoing[e.source]?.add(e.target)
    })

    // Assign levels via BFS (Kahn's algorithm)
    const level: Record<string, number> = {}
    const queue: string[] = []
    graphData.nodes.forEach((n) => {
      if (incoming[n.id].size === 0) {
        level[n.id] = 0
        queue.push(n.id)
      }
    })

    while (queue.length > 0) {
      const curr = queue.shift()!
      outgoing[curr]?.forEach((next) => {
        const newLevel = (level[curr] || 0) + 1
        level[next] = Math.max(level[next] || 0, newLevel)
        incoming[next].delete(curr)
        if (incoming[next].size === 0) queue.push(next)
      })
    }

    // Assign unleveled nodes (disconnected)
    graphData.nodes.forEach((n) => {
      if (level[n.id] === undefined) level[n.id] = 0
    })

    // Group by level and compute positions
    const levelGroups: Record<number, string[]> = {}
    Object.entries(level).forEach(([id, lvl]) => {
      if (!levelGroups[lvl]) levelGroups[lvl] = []
      levelGroups[lvl].push(id)
    })

    const xGap = 220
    const yGap = 80

    const layoutNodes: Node[] = graphData.nodes.map((n) => {
      const lvl = level[n.id] || 0
      const nodesAtLevel = levelGroups[lvl] || [n.id]
      const idx = nodesAtLevel.indexOf(n.id)
      const totalAtLevel = nodesAtLevel.length
      const yOffset = -(totalAtLevel - 1) * yGap / 2

      return {
        id: n.id,
        type: 'jobNode',
        data: { label: n.id },
        position: { x: lvl * xGap + 50, y: idx * yGap + yOffset + 300 },
      }
    })

    const layoutEdges: Edge[] = graphData.edges.map((e) => ({
      id: e.id,
      source: e.source,
      target: e.target,
      label: e.label === 's' ? '' : e.label,
      animated: true,
      style: { stroke: '#3b82f6', strokeWidth: 1.5 },
      markerEnd: { type: MarkerType.ArrowClosed, color: '#3b82f6', width: 16, height: 16 },
      labelStyle: { fill: '#9ca3af', fontSize: 10 },
    }))

    return { layoutNodes, layoutEdges }
  }, [graphData])

  const [nodes, setNodes, onNodesChange] = useNodesState(layoutNodes)
  const [edges, setEdges, onEdgesChange] = useEdgesState(layoutEdges)

  // Sync when data changes
  useMemo(() => {
    if (layoutNodes.length) setNodes(layoutNodes)
    if (layoutEdges.length) setEdges(layoutEdges)
  }, [layoutNodes, layoutEdges])

  const onNodeClick = useCallback((_: any, node: Node) => {
    setSelectedJob(node.id)
    setActivePage('monitor')
  }, [setSelectedJob, setActivePage])

  if (isLoading) {
    return (
      <div className="p-6 flex items-center justify-center h-[calc(100vh-2rem)] text-gray-500">
        Loading dependency graph...
      </div>
    )
  }

  return (
    <div className="p-6 h-[calc(100vh-2rem)]">
      <div className="bg-nexo-surface border border-nexo-border rounded-lg h-full">
        <div className="p-3 border-b border-nexo-border flex items-center justify-between">
          <h3 className="text-sm font-medium text-gray-300">Dependency Graph</h3>
          <span className="text-[10px] text-gray-500">
            {graphData?.nodes?.length ?? 0} jobs &middot; {graphData?.edges?.length ?? 0} edges
          </span>
        </div>
        <div className="h-[calc(100%-48px)]">
          <ReactFlow
            nodes={nodes}
            edges={edges}
            onNodesChange={onNodesChange}
            onEdgesChange={onEdgesChange}
            onNodeClick={onNodeClick}
            nodeTypes={nodeTypes}
            fitView
            fitViewOptions={{ padding: 0.2 }}
            minZoom={0.3}
            maxZoom={2}
            proOptions={{ hideAttribution: true }}
          >
            <Controls
              showInteractive={false}
              className="!bg-nexo-surface !border-nexo-border !shadow-lg [&>button]:!bg-nexo-surface [&>button]:!border-nexo-border [&>button]:!text-gray-400 [&>button:hover]:!bg-nexo-border"
            />
            <Background variant={BackgroundVariant.Dots} gap={20} size={1} color="#1a1d27" />
          </ReactFlow>
        </div>
      </div>
    </div>
  )
}
