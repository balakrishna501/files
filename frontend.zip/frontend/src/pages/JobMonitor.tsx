import { useState } from 'react'
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import { Play, Pause, Square, Search, RefreshCw } from 'lucide-react'
import { clsx } from 'clsx'
import { api } from '../api/client'
import { StatusBadge } from '../components/common/StatusBadge'
import { useStore } from '../stores/useStore'
import type { JobDefinition, JobRun } from '../types'

export function JobMonitor() {
  const [search, setSearch] = useState('')
  const [typeFilter, setTypeFilter] = useState('')
  const queryClient = useQueryClient()
  const { selectedJob, setSelectedJob } = useStore()

  const { data: jobs } = useQuery({
    queryKey: ['jobs', search, typeFilter],
    queryFn: () => api.listJobs({ search, job_type: typeFilter || undefined }),
  })

  const triggerMut = useMutation({
    mutationFn: (name: string) => api.triggerJob(name),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['jobs'] }),
  })

  const holdMut = useMutation({
    mutationFn: (name: string) => api.holdJob(name),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['jobs'] }),
  })

  const killMut = useMutation({
    mutationFn: (name: string) => api.killJob(name),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['jobs'] }),
  })

  return (
    <div className="p-6 flex gap-4 h-[calc(100vh-2rem)]">
      {/* Job list */}
      <div className="flex-1 flex flex-col bg-nexo-surface border border-nexo-border rounded-lg overflow-hidden">
        {/* Filters */}
        <div className="p-3 border-b border-nexo-border flex gap-3 items-center">
          <div className="relative flex-1">
            <Search size={14} className="absolute left-2.5 top-2.5 text-gray-500" />
            <input
              type="text"
              placeholder="Search jobs..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-full bg-nexo-bg border border-nexo-border rounded pl-8 pr-3 py-1.5 text-sm text-gray-200 placeholder-gray-600 focus:border-nexo-primary focus:outline-none"
            />
          </div>
          <select
            value={typeFilter}
            onChange={(e) => setTypeFilter(e.target.value)}
            className="bg-nexo-bg border border-nexo-border rounded px-2 py-1.5 text-sm text-gray-300"
          >
            <option value="">All Types</option>
            <option value="CMD">CMD</option>
            <option value="BOX">BOX</option>
            <option value="FW">FW</option>
          </select>
        </div>

        {/* Table */}
        <div className="flex-1 overflow-auto">
          <table className="w-full text-xs">
            <thead className="bg-nexo-bg sticky top-0">
              <tr className="text-gray-500 uppercase tracking-wider">
                <th className="text-left px-3 py-2">Job Name</th>
                <th className="text-left px-3 py-2">Type</th>
                <th className="text-left px-3 py-2">Machine</th>
                <th className="text-left px-3 py-2">Condition</th>
                <th className="text-left px-3 py-2">Status</th>
                <th className="text-right px-3 py-2">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-nexo-border">
              {(jobs ?? []).map((job) => (
                <tr
                  key={job.id}
                  onClick={() => setSelectedJob(job.job_name)}
                  className={clsx(
                    'hover:bg-nexo-border/20 cursor-pointer transition-colors',
                    selectedJob === job.job_name && 'bg-nexo-primary/5'
                  )}
                >
                  <td className="px-3 py-2 font-mono text-gray-200">{job.job_name}</td>
                  <td className="px-3 py-2 text-gray-400">{job.job_type}</td>
                  <td className="px-3 py-2 text-gray-500">{job.machine || '—'}</td>
                  <td className="px-3 py-2 text-gray-500 max-w-[200px] truncate">
                    {job.condition || '—'}
                  </td>
                  <td className="px-3 py-2">
                    <StatusBadge status={job.is_active ? 'ACTIVATED' : 'INACTIVE'} />
                  </td>
                  <td className="px-3 py-2 text-right">
                    <div className="flex items-center justify-end gap-1">
                      <button
                        onClick={(e) => { e.stopPropagation(); triggerMut.mutate(job.job_name) }}
                        className="p-1 rounded hover:bg-green-500/20 text-green-400"
                        title="Trigger"
                      >
                        <Play size={12} />
                      </button>
                      <button
                        onClick={(e) => { e.stopPropagation(); holdMut.mutate(job.job_name) }}
                        className="p-1 rounded hover:bg-purple-500/20 text-purple-400"
                        title="Hold"
                      >
                        <Pause size={12} />
                      </button>
                      <button
                        onClick={(e) => { e.stopPropagation(); killMut.mutate(job.job_name) }}
                        className="p-1 rounded hover:bg-red-500/20 text-red-400"
                        title="Kill"
                      >
                        <Square size={12} />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Detail panel */}
      {selectedJob && <JobDetailPanel jobName={selectedJob} />}
    </div>
  )
}

function JobDetailPanel({ jobName }: { jobName: string }) {
  const { data: job } = useQuery({
    queryKey: ['job', jobName],
    queryFn: () => api.getJob(jobName),
  })

  const { data: runs } = useQuery({
    queryKey: ['job-runs', jobName],
    queryFn: () => api.getJobRuns(jobName, 10),
  })

  const setSelectedJob = useStore((s) => s.setSelectedJob)

  if (!job) return null

  return (
    <div className="w-96 bg-nexo-surface border border-nexo-border rounded-lg overflow-auto">
      <div className="p-4 border-b border-nexo-border flex items-center justify-between">
        <h3 className="font-mono text-sm font-medium">{job.job_name}</h3>
        <button
          onClick={() => setSelectedJob(null)}
          className="text-gray-500 hover:text-gray-300 text-xs"
        >
          Close
        </button>
      </div>

      <div className="p-4 space-y-3 text-xs">
        <Row label="Type" value={job.job_type} />
        <Row label="Command" value={job.command} mono />
        <Row label="Machine" value={job.machine} />
        <Row label="Condition" value={job.condition} mono />
        <Row label="Schedule" value={job.start_times || job.cron_expression} />
        <Row label="Owner" value={job.owner} />
        <Row label="Max Retries" value={String(job.max_retries)} />
        <Row label="Description" value={job.description} />
        {job.tags.length > 0 && (
          <div>
            <span className="text-gray-500">Tags: </span>
            {job.tags.map((t) => (
              <span key={t} className="inline-block bg-nexo-border rounded px-1.5 py-0.5 mr-1 text-gray-300">
                {t}
              </span>
            ))}
          </div>
        )}
      </div>

      {/* Run History */}
      <div className="border-t border-nexo-border">
        <div className="px-4 py-2 text-xs font-medium text-gray-400">Run History</div>
        <div className="divide-y divide-nexo-border max-h-64 overflow-auto">
          {(runs ?? []).map((run) => (
            <div key={run.id} className="px-4 py-2 text-xs flex items-center gap-3">
              <span className="text-gray-500">#{run.run_number}</span>
              <StatusBadge status={run.status} />
              <span className="text-gray-500">
                {run.duration_seconds ? `${run.duration_seconds.toFixed(1)}s` : '—'}
              </span>
              <span className="text-gray-600 ml-auto">
                {run.exit_code !== null && run.exit_code !== undefined ? `exit:${run.exit_code}` : ''}
              </span>
            </div>
          ))}
          {(!runs || runs.length === 0) && (
            <div className="px-4 py-4 text-center text-gray-600 text-xs">No runs yet</div>
          )}
        </div>
      </div>
    </div>
  )
}

function Row({ label, value, mono }: { label: string; value?: string | null; mono?: boolean }) {
  if (!value) return null
  return (
    <div>
      <span className="text-gray-500">{label}: </span>
      <span className={clsx('text-gray-200', mono && 'font-mono')}>{value}</span>
    </div>
  )
}
