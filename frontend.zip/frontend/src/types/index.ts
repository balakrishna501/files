// ── Enums ────────────────────────────────────────────────────────

export type JobType = 'CMD' | 'BOX' | 'FW' | 'FTP'

export type JobStatus =
  | 'INACTIVE' | 'ACTIVATED' | 'STARTING' | 'RUNNING'
  | 'SUCCESS' | 'FAILURE' | 'TERMINATED'
  | 'RESTART' | 'ON_HOLD' | 'ON_ICE' | 'QUE_WAIT'

export type AlertSeverity = 'INFO' | 'WARNING' | 'CRITICAL'
export type AlertStatus = 'OPEN' | 'ACKNOWLEDGED' | 'RESOLVED' | 'ESCALATED'

// ── Job Definition ──────────────────────────────────────────────

export interface JobDefinition {
  id: string
  job_name: string
  job_type: JobType
  command?: string
  machine?: string
  owner?: string
  box_name?: string
  start_times?: string
  cron_expression?: string
  condition?: string
  max_run_alarm?: number
  max_retries: number
  description?: string
  tags: string[]
  priority: number
  is_active: boolean
  watch_file?: string
  timezone: string
  created_at: string
  updated_at: string
}

// ── Job Run ─────────────────────────────────────────────────────

export interface JobRun {
  id: string
  job_id: string
  run_number: number
  status: JobStatus
  exit_code?: number
  scheduled_time?: string
  start_time?: string
  end_time?: string
  duration_seconds?: number
  machine?: string
  worker_id?: string
  retry_attempt: number
  stdout_tail?: string
  stderr_tail?: string
  triggered_by?: string
  created_at: string
}

// ── Dashboard ───────────────────────────────────────────────────

export interface DashboardStats {
  total_jobs: number
  running_now: number
  failed_24h: number
  success_24h: number
  on_hold: number
  sla_at_risk: number
}

// ── Alert ───────────────────────────────────────────────────────

export interface Alert {
  id: string
  job_name?: string
  run_id?: string
  severity: AlertSeverity
  status: AlertStatus
  title: string
  description?: string
  ai_analysis?: string
  remediation_action?: string
  acknowledged_by?: string
  resolved_at?: string
  created_at: string
}

// ── Event ───────────────────────────────────────────────────────

export interface NexoEvent {
  id: string
  event_type: string
  source: string
  detail_type?: string
  detail: Record<string, any>
  job_name?: string
  correlation_id?: string
  created_at: string
}

// ── Graph (React Flow) ──────────────────────────────────────────

export interface GraphData {
  nodes: { id: string; data: { label: string }; position: { x: number; y: number } }[]
  edges: { id: string; source: string; target: string; label?: string }[]
}

// ── AI ──────────────────────────────────────────────────────────

export interface ChatMessage {
  role: 'user' | 'assistant'
  content: string
}

export interface ChatResponse {
  response: string
  actions_taken: string[]
  suggestions: string[]
}
