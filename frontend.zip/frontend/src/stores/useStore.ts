import { create } from 'zustand'
import type { JobDefinition, ChatMessage } from '../types'

interface NexoStore {
  // Selected job for detail panel
  selectedJob: string | null
  setSelectedJob: (name: string | null) => void

  // Sidebar nav
  activePage: string
  setActivePage: (page: string) => void

  // Chat
  chatMessages: ChatMessage[]
  addChatMessage: (msg: ChatMessage) => void
  clearChat: () => void

  // WebSocket events (latest N)
  realtimeEvents: any[]
  addRealtimeEvent: (event: any) => void
}

export const useStore = create<NexoStore>((set) => ({
  selectedJob: null,
  setSelectedJob: (name) => set({ selectedJob: name }),

  activePage: 'dashboard',
  setActivePage: (page) => set({ activePage: page }),

  chatMessages: [],
  addChatMessage: (msg) =>
    set((s) => ({ chatMessages: [...s.chatMessages, msg] })),
  clearChat: () => set({ chatMessages: [] }),

  realtimeEvents: [],
  addRealtimeEvent: (event) =>
    set((s) => ({
      realtimeEvents: [event, ...s.realtimeEvents].slice(0, 100),
    })),
}))
