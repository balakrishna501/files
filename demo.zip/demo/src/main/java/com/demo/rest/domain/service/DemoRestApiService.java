package com.demo.rest.domain.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.demo.rest.app.dto.EmpDTO;
import com.demo.rest.domain.entity.Employee;
import com.demo.rest.domain.repository.IDemoRestApiRepository;

@Service
public class DemoRestApiService {

	@Autowired
	IDemoRestApiRepository demoRestApiRepository;

	public void addEmp(EmpDTO dto) {

		demoRestApiRepository.save(convertToEntity(dto));

	}

	public List<EmpDTO> fetch() {
		List<EmpDTO> listDto = new ArrayList<EmpDTO>();
		List<Employee> list = demoRestApiRepository.findAll();
		for (Employee emp : list) {
			EmpDTO dto = new EmpDTO();
			dto.setEmpId(emp.getEmpId());
			dto.setEmpEmail(emp.getEmpEmail());
			dto.setEmpName(emp.getEmpName());
			listDto.add(dto);
		}
		return listDto;
	}

	public EmpDTO fetchbyId(String id) {
		// TODO Auto-generated method stub
		Employee emp = demoRestApiRepository.findById(id).get();
		if (emp != null) {
			EmpDTO dto = new EmpDTO();
			dto.setEmpId(emp.getEmpId());
			dto.setEmpEmail(emp.getEmpEmail());
			dto.setEmpName(emp.getEmpName());
			return dto;
		}
		return null;
	}

	private Employee convertToEntity(EmpDTO dto) {
		Employee employee = new Employee();
		if (dto != null) {

			employee.setEmpId(dto.getEmpId());
			employee.setEmpEmail(dto.getEmpEmail());
			employee.setEmpName(dto.getEmpName());
		}
		return employee;
	}
}
