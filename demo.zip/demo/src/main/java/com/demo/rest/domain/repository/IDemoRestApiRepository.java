package com.demo.rest.domain.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.demo.rest.domain.entity.Employee;

@Repository
public interface IDemoRestApiRepository extends JpaRepository<Employee, String>{

}
