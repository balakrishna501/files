package com.demo.rest.app.serive;

import java.util.List;

import com.demo.rest.app.dto.EmpDTO;

public interface IDemoRestApiAppService {

	public void addEmp(EmpDTO dto);
	
	public List<EmpDTO> fetch();
	
	public EmpDTO fetchbyId(String id);
}
