package com.demo.rest.app.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.demo.rest.app.dto.EmpDTO;
import com.demo.rest.app.serive.IDemoRestApiAppService;
import com.demo.rest.domain.service.DemoRestApiService;

@Service
public class DemoRestApiAppServiceImpl implements IDemoRestApiAppService{
	
	@Autowired
	DemoRestApiService demoRestApiService;	

	@Override
	public void addEmp(EmpDTO dto) {
		demoRestApiService.addEmp(dto);
	}

	@Override
	public List<EmpDTO> fetch() {
		// TODO Auto-generated method stub
		return demoRestApiService.fetch();
	}

	@Override
	public EmpDTO fetchbyId(String id) {
		// TODO Auto-generated method stub
		return demoRestApiService.fetchbyId(id);
	}

}
