package com.demo.rest.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.demo.rest.app.dto.EmpDTO;
import com.demo.rest.app.serive.IDemoRestApiAppService;

@RestController
public class DemoRestApiController {

	@Autowired
	IDemoRestApiAppService idemoRestApiAppService;

	@PostMapping("/emp/add")
	public String addEmp(@RequestBody EmpDTO dto) {
		idemoRestApiAppService.addEmp(dto);
		return "employe created succefully ";
	}

	@GetMapping("/emp/fetchAll")
	public List<EmpDTO> fetchAll() {

		return idemoRestApiAppService.fetch();
	}

	@GetMapping("/emp/fetchById")
	public EmpDTO fetchById(@RequestParam("id") String id) {

		return idemoRestApiAppService.fetchbyId(id);
	}
}
